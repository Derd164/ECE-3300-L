`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/21/2026 01:39:18 PM
// Design Name: 
// Module Name: ops2_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module ops2_tb; // no hardware -- a printing lab
    reg [31:0] digits;
    reg [2:0] sel;
    integer s;
initial begin
    digits = 32'h76543210; // every nibble different on purpose
    $display("digits = %h", digits);
    $display("--- indexed part-select: [sel*4 +: 4] picks nibble number sel ---");
    for (s = 0; s < 8; s = s + 1) begin
        sel = s[2:0];
        $display("sel=%0d digits[sel*4 +: 4] = %h", sel, digits[sel*4 +: 4]);
    end
    $display("--- one-cold: ~(8'b0000_0001 << sel) picks digit sel, ACTIVE LOW ---");
    for (s = 0; s < 8; s = s + 1) begin
        sel = s[2:0];
        $display("sel=%0d AN = %b", sel, ~(8'b0000_0001 << sel));
    end
    $finish;
end
endmodule