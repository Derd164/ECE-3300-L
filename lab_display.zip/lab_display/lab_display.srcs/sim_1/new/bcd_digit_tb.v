`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/21/2026 01:55:14 PM
// Design Name: 
// Module Name: bcd_digit_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module bcd_digit_tb;
    reg clk, rst, en;
    wire [3:0] q;
    wire ro;
    integer i, errors;
    reg [3:0] model;
    bcd_digit dut (.clk(clk), .rst(rst), .en(en), .q(q), .ro(ro));
    always #5 clk = ~clk;
initial begin
    clk = 0; errors = 0;
    // CORNER 1: reset
    rst = 1; en = 0; @(posedge clk); #1;
    if (q !== 4'd0) begin errors=errors+1; $display("FAIL reset"); end
    // walk up to the edge of the cliff: 0 -> 9
    rst = 0; en = 1;
    for (i = 1; i <= 9; i = i + 1) begin
        @(posedge clk); #1;
        if (q !== i[3:0]) begin
            errors=errors+1; $display("FAIL counting to %0d, q=%0d", i, q);
        end
    end
    // CORNER 2: parked AT 9 with en=0 -- must hold, ro must stay quiet
    en = 0; @(posedge clk); #1;
    if (q !== 4'd9) begin errors=errors+1; $display("FAIL hold at 9"); end
    if (ro !== 1'b0) begin errors=errors+1; $display("FAIL ro while parked"); end
    // CORNER 3: the rollover itself
    en = 1; #1; // let the combinational ro settle
    if (ro !== 1'b1) begin errors=errors+1; $display("FAIL ro at 9 with en"); end
    @(posedge clk); #1;
    if (q !== 4'd0) begin errors=errors+1; $display("FAIL 9 -> 0 wrap"); end
    if (ro !== 1'b0) begin errors=errors+1; $display("FAIL ro must drop after wrap"); end
    // CORNER 4: first step on the other side: 0 -> 1
    @(posedge clk); #1;
    if (q !== 4'd1) begin errors=errors+1; $display("FAIL 0 -> 1 after wrap"); end
    // the sweep: 25 more ticks against a software model -- crosses 9 twice more
    model = q;
    for (i = 0; i < 25; i = i + 1) begin
        @(posedge clk); #1;
        model = (model == 4'd9) ? 4'd0 : model + 1'b1;
        if (q !== model) begin
        errors=errors+1;
            $display("FAIL sweep step %0d q=%0d model=%0d", i, q, model);
        end
    end
    $display("done: %0d errors", errors);
    $finish;
end
endmodule