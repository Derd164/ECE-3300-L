`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/21/2026 01:44:25 PM
// Design Name: 
// Module Name: display8_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module display8_tb;
    reg clk;
    reg [31:0] digits;
    wire [6:0] seg;
    wire [7:0] an;
    wire dp;
    integer i, k, errors, zeros, whichdigit;
    reg [6:0] glyphs [0:15]; // the Lab 2 Step 7 table
    reg [7:0] seen; // coverage: which digits took a turn
    reg [3:0] nib;
    // SEL_LO shrunk from 17 to 2: digit changes every 4 clocks -- watchable
    display8 #(.SEL_LO(2)) dut (
        .clk(clk),
        .digits(digits),
        .SEG(seg),
        .AN(an),
        .DP(dp)
    );
always #5 clk = ~clk;
initial begin
    glyphs[0] = 7'b1000000;
    glyphs[1] = 7'b1111001;
    glyphs[2] = 7'b0100100;
    glyphs[3] = 7'b0110000;
    glyphs[4] = 7'b0011001;
    glyphs[5] = 7'b0010010;
    glyphs[6] = 7'b0000010;
    glyphs[7] = 7'b1111000;
    glyphs[8] = 7'b0000000;
    glyphs[9] = 7'b0010000;
    glyphs[10] = 7'b0001000;
    glyphs[11] = 7'b0000011;
    glyphs[12] = 7'b1000110;
    glyphs[13] = 7'b0100001;
    glyphs[14] = 7'b0000110;
    glyphs[15] = 7'b0001110;
    clk = 0;
    errors = 0;
    seen = 8'b0;
    digits = 32'h76543210; // every digit different on purpose
    for (i = 0; i < 64; i = i + 1) begin // 2 full sweeps of 8 digits
        @(posedge clk);
        #1;
        // CORNER 1 (a must-always property): AN one-cold on EVERY cycle
        zeros = 0;
        for (k = 0; k < 8; k = k + 1) begin
            if (an[k] == 1'b0)
                zeros = zeros + 1;
        end
        if (zeros != 1) begin
            errors = errors + 1;
            $display("FAIL: AN=%b enables %0d digits at once", an, zeros);
        end
        // which digit is enabled right now?
        whichdigit = 0;
        for (k = 0; k < 8; k = k + 1) begin
            if (an[k] == 1'b0)
                whichdigit = k;
        end
        seen[whichdigit] = 1'b1;
        // CORNER 2 (a matching property): SEG must show THAT digit's value
        nib = digits[whichdigit*4 +: 4];
        if (seg !== glyphs[nib]) begin
            errors = errors + 1;
            $display(
                "FAIL: digit %0d holds %h but SEG shows %b",
                whichdigit, nib, seg
            );
        end
        if (dp !== 1'b1) begin
            errors = errors + 1;
            $display("FAIL: DP on");
        end
    end
    // CORNER 3 (a coverage check): did every digit get a turn?
    if (seen !== 8'b11111111) begin
        errors = errors + 1;
        $display("FAIL: coverage %b - some digit was never enabled", seen);
    end
    $display("coverage %b - all 8 digits took a turn", seen);
    $display("done: %0d errors", errors);
    $finish;
end
endmodule