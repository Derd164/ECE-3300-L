`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/21/2026 02:00:35 PM
// Design Name: 
// Module Name: bcd_chain_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module bcd_chain_tb;
    reg clk, rst, en;
    wire [7:0] d2; // N=2: small enough to REACH the corner
    wire [31:0] d8; // N=8: the real thing, spot-checked
    integer i, j, errors;
    integer model2, model8;
    bcd_chain #(.N(2)) chain2 (.clk(clk), .rst(rst), .en(en), .digits(d2));
    bcd_chain #(.N(8)) chain8 (.clk(clk), .rst(rst), .en(en), .digits(d8));
    always #5 clk = ~clk;
    function [3:0] nibble_of(input integer value, input integer pos);
    integer p, k;
    begin
        p = 1;
        for (k = 0; k < pos; k = k + 1) p = p * 10;
        nibble_of = (value / p) % 10;
    end
    endfunction
initial begin
    clk = 0; errors = 0;
    // CORNER 1: reset clears every digit of both chains
    rst = 1; en = 0; @(posedge clk); #1;
    if (d2 !== 8'h00 || d8 !== 32'h00000000) begin
        errors = errors + 1; $display("FAIL reset");
    end
    rst = 0; en = 1; model2 = 0; model8 = 0;
    // 205 ticks: the small chain crosses its BIG corner (99 -> 00) twice
    for (i = 1; i <= 205; i = i + 1) begin
        @(posedge clk); #1;
        model2 = (model2 + 1) % 100;
        model8 = model8 + 1;
        if (d2[3:0] !== (model2 % 10) || d2[7:4] !== (model2 / 10)) begin
            errors = errors + 1;
            $display("FAIL small chain tick %0d: shows %h, model %0d",
            i, d2, model2);
        end
        for (j = 0; j < 8; j = j + 1)
        if (d8[j*4 +: 4] !== nibble_of(model8, j)) begin
            errors = errors + 1;
            $display("FAIL full chain tick %0d digit %0d", i, j);
        end
        if (i == 99)
        $display("tick 99: small chain shows %h%h", d2[7:4], d2[3:0]);
        if (i == 100)
        $display("tick 100: small chain shows %h%h <- the 99 -> 00 corner",
        d2[7:4], d2[3:0]);
        if (i == 101)
        $display("tick 101: small chain shows %h%h", d2[7:4], d2[3:0]);
    end
    $display("full chain after 205 ticks: %h", d8);
    $display("done: %0d errors", errors);
    $finish;
end
endmodule