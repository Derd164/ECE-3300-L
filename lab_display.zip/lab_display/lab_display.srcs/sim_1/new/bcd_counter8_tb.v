`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/21/2026 02:06:53 PM
// Design Name: 
// Module Name: bcd_counter8_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module bcd_counter8_tb;
    reg clk, btnc;
    wire [6:0] seg;
    wire dp;
    wire [7:0] an;
    wire [3:0] led;
    integer i, errors;
    // TICK_MAX shrunk from 10 million to 4: same logic, watchable sim
    bcd_counter8 #(.TICK_MAX(4)) dut (.CLK100MHZ(clk), .BTNC(btnc),
    .SEG(seg), .DP(dp), .AN(an), .LED(led));
    always #5 clk = ~clk;
initial begin
    clk = 0; errors = 0;
    btnc = 1; @(posedge clk); #1; btnc = 0; // pulse reset
    if (led !== 4'd0) begin errors=errors+1; $display("FAIL reset"); end
    for (i = 1; i <= 12; i = i + 1) begin
        repeat (4) @(posedge clk); #1; // one full tick period
        if (led !== (i % 10)) begin
            errors = errors + 1;
            $display("FAIL tick %0d: LED=%0d", i, led);
        end
    end
    $display("after 12 ticks the ones digit shows %0d (12 mod 10 = 2)", led);
    $display("done: %0d errors", errors);
    $finish;
end
endmodule