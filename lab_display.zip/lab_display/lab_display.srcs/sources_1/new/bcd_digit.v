`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/21/2026 01:54:02 PM
// Design Name: 
// Module Name: bcd_digit
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module bcd_digit (
    input clk, rst, en,
    output reg [3:0] q, // counts 0..9, then wraps
    output ro // rollover: THIS tick takes me past 9
);
assign ro = en && (q == 4'd9); // combinational, one tick wide
always @(posedge clk) begin
    if (rst) q <= 4'd0;
    else if (en) q <= (q == 4'd9) ? 4'd0 : q + 1'b1;
    // no else: q holds -- Lab 2 Step 9, same habit
end
endmodule