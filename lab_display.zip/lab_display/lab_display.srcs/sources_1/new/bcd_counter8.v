`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/21/2026 02:04:46 PM
// Design Name: 
// Module Name: bcd_counter8
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module bcd_counter8 #(
    parameter TICK_MAX = 10_000_000 // 100 MHz / 10M = 10 counts per second
)(
    input CLK100MHZ,
    input BTNC, // press = reset the count to zero
    output [6:0] SEG,
    output DP,
    output [7:0] AN,
    output [3:0] LED // the ones digit, in binary
);
reg [23:0] tickcnt = 0; // 2^24 > 10M, so 24 bits fit
reg tick = 0;
always @(posedge CLK100MHZ) begin // the metronome, verbatim from Lab 2
    if (tickcnt == TICK_MAX - 1) begin
        tickcnt <= 0;
        tick <= 1'b1; // one-cycle pulse
    end else begin
    tickcnt <= tickcnt + 1'b1;
    tick <= 1'b0;
end
end
wire [31:0] digits;
bcd_chain #(.N(8)) chain
(.clk(CLK100MHZ), .rst(BTNC), .en(tick), .digits(digits));
display8 driver // SEL_LO keeps its board default, 17
(.clk(CLK100MHZ), .digits(digits), .SEG(SEG), .AN(AN), .DP(DP));
assign LED = digits[3:0]; // ones digit in binary: never above 1001
endmodule