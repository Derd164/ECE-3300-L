`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/21/2026 01:59:36 PM
// Design Name: 
// Module Name: bcd_chain
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module bcd_chain #(
    parameter N = 8 // how many decimal digits
)(
    input clk, rst, en, // en = one tick per count
    output [4*N-1:0] digits // digit 0 (ones) in bits [3:0]
);
    wire [N:0] carry; // carry[0] in, carry[N] falls off the end
    assign carry[0] = en;
    genvar gi;
    generate
    for (gi = 0; gi < N; gi = gi + 1) begin : DIGITS
    bcd_digit d (
    .clk (clk),
    .rst (rst),
    .en (carry[gi]), // I may count only when everyone
    // below me rolls over this tick
    .q (digits[gi*4 +: 4]),
    .ro (carry[gi+1])
);
end
endgenerate
endmodule