`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/21/2026 01:42:45 PM
// Design Name: 
// Module Name: display8
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module display8 #(
    parameter SEL_LO = 17 // which counter bit starts the 3-bit
    // digit-select field. 17 on the board;
    // the bench shrinks it to 2.
)(
    input clk,
    input [31:0] digits, // 8 BCD nibbles; digit 0 = bits [3:0]
    output [6:0] SEG, // shared by all 8 digits, active low
    output [7:0] AN, // digit enables, active low, one-cold
    output DP // decimal point, held OFF
);
reg [19:0] refcnt = 0; // free-running refresh counter
always @(posedge clk)
refcnt <= refcnt + 1'b1;
wire [2:0] sel = refcnt[SEL_LO +: 3]; // which digit's turn is it?
wire [3:0] nib = digits[sel*4 +: 4]; // that digit's value
sseg_hex glyph (.hex(nib), .seg(SEG)); // Lab 2 Step 7, reused as-is
assign AN = ~(8'b0000_0001 << sel); // exactly one enable low
assign DP = 1'b1; // dot off
endmodule