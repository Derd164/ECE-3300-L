`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/02/2026 01:52:07 PM
// Design Name: 
// Module Name: decoder4x16_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module decoder4x16_tb; // no ports!
reg [3:0] a; // we drive this
wire [15:0] y; // we watch this
integer i, errors;
reg [15:0] expected;
decoder4x16 dut ( .a(a), .y(y) );
initial begin
    errors = 0;
    for (i = 0; i < 16; i = i + 1) begin
        a = i;
        #10; // let the gates settle
        expected = 16'd1 << i; // a 1 shifted to slot i
        if (y !== expected) begin
            errors = errors + 1;
            $display("FAIL a=%0d y=%b", i, y);
        end
    end
    $display("done: %0d errors", errors);
    $finish;
end
endmodule