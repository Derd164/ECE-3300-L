`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/02/2026 01:43:27 PM
// Design Name: 
// Module Name: decoder4x16
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module decoder4x16 (
    input [3:0] a, // the number, from 4 switches
    output [15:0] y // one-hot, to 16 LEDs
);

wire [3:0] an; // inverted copies of the inputs
not n3 (an[3], a[3]);
not n2 (an[2], a[2]);
not n1 (an[1], a[1]);
not n0 (an[0], a[0]);
// output a[3]? a[2]? a[1]? a[0]? index
and g0 (y[0], an[3], an[2], an[1], an[0]); // 0000
and g1 (y[1], an[3], an[2], an[1], a[0] ); // 0001
and g2 (y[2], an[3], an[2], a[1], an[0]); // 0010
and g3 (y[3], an[3], an[2], a[1], a[0] ); // 0011
and g4 (y[4], an[3], a[2], an[1], an[0]); // 0100
and g5 (y[5], an[3], a[2], an[1], a[0] ); // 0101
and g6 (y[6], an[3], a[2], a[1], an[0]); // 0110
and g7 (y[7], an[3], a[2], a[1], a[0] ); // 0111
and g8 (y[8], a[3], an[2], an[1], an[0]); // 1000
and g9 (y[9], a[3], an[2], an[1], a[0] ); // 1001
and g10 (y[10], a[3], an[2], a[1], an[0]); // 1010
and g11 (y[11], a[3], an[2], a[1], a[0] ); // 1011
and g12 (y[12], a[3], a[2], an[1], an[0]); // 1100
and g13 (y[13], a[3], a[2], an[1], a[0] ); // 1101
and g14 (y[14], a[3], a[2], a[1], an[0]); // 1110
and g15 (y[15], a[3], a[2], a[1], a[0] ); // 1111
endmodule
