`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/21/2026 01:03:10 PM
// Design Name: 
// Module Name: lfsr_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module lfsr_tb;
reg clk, load, en;
reg [3:0] seed4;
reg [15:0] seed16;
wire [3:0] q4;
wire [15:0] q16;
reg [15:0] seen; // coverage: one bit per 4-bit state
integer i, s, errors, period, distinct, bad;
// the 4-bit register of the theory pages: x^4 + x^3 + 1
lfsr #(.N(4), .TAPS(4'b1100)) r4
(.clk(clk), .load(load), .en(en), .seed(seed4), .q(q4));
// the 16-bit register the board will use: parameters left at default
lfsr r16 (.clk(clk), .load(load), .en(en), .seed(seed16), .q(q16));
always #5 clk = ~clk;
initial begin
clk = 0; errors = 0; en = 0; seed16 = 16'h0000;
// CORNER 1 (boundary): seed 0000 -- the villain. It must stay stuck.
seed4 = 4'b0000; load = 1; @(posedge clk); #1; load = 0; en = 1;
repeat (20) @(posedge clk); #1;
if (q4 !== 4'b0000) begin
errors = errors + 1; $display("FAIL: zero escaped to %b", q4);
end
$display("seed 0000: after 20 steps q = %b <- the lockup corner", q4);
// one lap from seed 0001, watching every state go by
en = 0; seed4 = 4'b0001; load = 1; @(posedge clk); #1; load = 0; en = 1;
seen = 16'b0; seen[q4] = 1'b1; period = 0;
for (i = 1; i <= 20; i = i + 1) begin
@(posedge clk); #1;
// CORNER 2 (must-always): a nonzero seed NEVER reaches zero
if (q4 === 4'b0000) begin
errors = errors + 1; $display("FAIL: reached 0000 at step %0d", i);
end
seen[q4] = 1'b1;
if (q4 == seed4 && period == 0) period = i;
end
// CORNER 3 (coverage): 15 different states visited, 0000 never
distinct = 0;
for (s = 0; s < 16; s = s + 1) if (seen[s]) distinct = distinct + 1;
if (period != 15 || distinct != 15 || seen[0] !== 1'b0) begin
errors = errors + 1; $display("FAIL: period/coverage");
end
$display("seed 0001: period %0d, distinct states %0d, zero seen = %b",
period, distinct, seen[0]);
// CORNER 4 (coverage of seeds): EVERY nonzero seed gives period 15
bad = 0;
for (s = 1; s < 16; s = s + 1) begin
en = 0; seed4 = s[3:0]; load = 1; @(posedge clk); #1; load = 0; en = 1;
period = 0;
for (i = 1; i <= 20; i = i + 1) begin
@(posedge clk); #1;
if (q4 == seed4 && period == 0) period = i;
end
if (period != 15) begin
bad = bad + 1; $display("FAIL: seed %b period %0d", seed4, period);
end
end
errors = errors + bad;
$display("all 15 nonzero seeds: %0d with a period other than 15", bad);
// CORNER 5 (mode change): load arrives while en is still high
seed4 = 4'b1010; load = 1; @(posedge clk); #1; load = 0;
if (q4 !== 4'b1010) begin
errors = errors + 1; $display("FAIL: en beat load, q=%b", q4);
end
$display("load during a run: q = %b <- load wins over en", q4);
// the full-size register: one lap of 2^16 - 1 = 65535 steps
en = 0; seed16 = 16'h0001; load = 1; @(posedge clk); #1; load = 0; en = 1;
period = 0; i = 0;
while (period == 0 && i < 70000) begin
@(posedge clk); #1; i = i + 1;
if (q16 === 16'h0000) begin
errors = errors + 1; $display("FAIL: 16-bit reached zero"); i = 70000;
end
if (q16 == seed16) period = i;
end
if (period != 65535) begin
errors = errors + 1; $display("FAIL: 16-bit period %0d", period);
end
$display("16-bit seed 0001: period %0d", period);
$display("done: %0d errors", errors);
$finish;
end
endmodule