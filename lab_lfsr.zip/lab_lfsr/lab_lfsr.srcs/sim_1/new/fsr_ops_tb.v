`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/21/2026 12:59:17 PM
// Design Name: 
// Module Name: fsr_ops_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module fsr_ops_tb; // no hardware -- a printing lab
    reg [3:0] s, taps;
    reg fb;
    integer i;
initial begin
    $display("--- tool 1: reduction XOR ^v = 1 when v holds an ODD number of 1s ---");
    $display("^0000 = %b ^0001 = %b ^0110 = %b ^0111 = %b",
    ^4'b0000, ^4'b0001, ^4'b0110, ^4'b0111);
    taps = 4'b1100; // a 1 marks every bit that feeds back
    s = 4'b1001;
    $display("--- mask, then reduce: s=%b taps=%b s&taps=%b ^(s&taps)=%b ---",
    s, taps, s & taps, ^(s & taps));
    $display("--- tool 2: shift with feedback s <= {s[2:0], fb} ---");
    s = 4'b0001; // the seed
    for (i = 1; i <= 16; i = i + 1) begin
        fb = ^(s & taps); // fb = s3 XOR s2
        $display("#%2d s=%b hex %h fb=%b", i, s, s, fb);
        s = {s[2:0], fb}; // everyone moves left, fb enters at s0
    end
    $finish;
end
endmodule