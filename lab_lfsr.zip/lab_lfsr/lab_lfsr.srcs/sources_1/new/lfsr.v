`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/21/2026 01:01:17 PM
// Design Name: 
// Module Name: lfsr
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module lfsr #(
    parameter N = 16, // how many flip-flops
    parameter TAPS = 16'hD008 // x^16+x^15+x^13+x^4+1: bits 15,14,12,3
)(
    input clk,
    input load, // copy seed in -- wins over en
    input en, // take one step on this clock
    input [N-1:0] seed,
    output reg [N-1:0] q // the state; q[N-1] is the oldest bit
);
wire fb = ^(q & TAPS); // XOR of every tapped bit
always @(posedge clk) begin
    if (load) q <= seed;
    else if (en) q <= {q[N-2:0], fb}; // shift left, fb enters at q[0]
    // no else: q holds -- the Lab 2 habit
end
endmodule