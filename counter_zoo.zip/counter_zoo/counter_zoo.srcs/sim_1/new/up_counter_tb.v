`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/21/2026 12:34:51 PM
// Design Name: 
// Module Name: up_counter_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module up_counter_tb;
    reg clk, rst, en;
    wire [3:0] q;
    integer i, errors;
    up_counter #(.N(4)) dut (.clk(clk), .rst(rst),
    .en(en), .q(q));
    always #5 clk = ~clk; // 10 ns period = 100 MHz
initial begin
    clk = 0; errors = 0;
    // corner 1: reset must win, even with en = 1
    rst = 1; en = 1; @(posedge clk); #1;
    $display("reset q=%0d", q);
    if (q !== 4'd0) errors = errors + 1;
    // corner 2: en = 0 must HOLD
    rst = 0; en = 0; @(posedge clk); #1;
    $display("en=0 q=%0d", q);
    if (q !== 4'd0) errors = errors + 1;
    // sweep: 20 ticks > 16 values -> crosses the wrap
    en = 1;
    for (i = 1; i <= 20; i = i + 1) begin
        @(posedge clk); #1;
        if (i >= 14 && i <= 17)
        $display("tick %0d q=%0d", i, q);
        if (q !== i % 16) errors = errors + 1; // golden
    end
    $display("done: %0d errors", errors);
    $finish;
end
endmodule