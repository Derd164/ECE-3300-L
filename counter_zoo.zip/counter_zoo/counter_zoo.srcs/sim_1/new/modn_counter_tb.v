`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/23/2026 11:35:53 AM
// Design Name: 
// Module Name: modn_counter_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module modn_counter_tb;
    reg clk, rst, en;
    wire [3:0] q;
    wire co;
    integer i, errors;
    modn_counter #(.N(4), .MOD(10)) dut (.clk(clk),
    .rst(rst), .en(en), .q(q), .co(co));
    always #5 clk = ~clk;
initial begin
    clk = 0; errors = 0;
    rst = 1; en = 1; @(posedge clk); #1;
    rst = 0;
    for (i = 1; i <= 25; i = i + 1) begin
    @(posedge clk); #1;
    if (i >= 8 && i <= 11)
    $display("tick %0d q=%0d co=%b", i, q, co);
    if (q !== i % 10) errors = errors + 1;
    if (co !== (i % 10 == 9)) errors = errors + 1;
    end
    en = 0; #1; // corner: co needs en
    $display("en=0 q=%0d co=%b", q, co);
    if (co !== 1'b0) errors = errors + 1;
    $display("done: %0d errors", errors);
    $finish;
end
endmodule