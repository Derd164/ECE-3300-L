`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/23/2026 12:26:13 PM
// Design Name: 
// Module Name: counter_zoo_top_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module counter_zoo_top_tb;
    reg clk, resetn;
    reg [15:0] sw;
    wire [7:0] led, an;
    wire ca, cb, cc, cd, ce, cf, cg, dp;
    integer errors;
    // TICK_MAX = 2: one tick every 2 clocks
    counter_zoo_top #(.TICK_MAX(2)) dut (
    .CLK100MHZ(clk), .CPU_RESETN(resetn), .SW(sw),
    .LED(led), .AN(an), .CA(ca), .CB(cb), .CC(cc),
    .CD(cd), .CE(ce), .CF(cf), .CG(cg), .DP(dp));
    always #5 clk = ~clk;
    task ticks(input integer n); // n ticks = 2n clocks
    repeat (2*n) @(posedge clk);
    endtask
initial begin
    clk = 0; errors = 0; sw = 16'h0000;
    resetn = 0; repeat (20) @(posedge clk); // press
    resetn = 1; @(posedge clk); // tick_gen warm-up
    ticks(5); #1;
    $display("mode 0 up LED=%b", led);
    if (led !== 8'd5) errors = errors + 1;
    sw[2:0] = 3'd4; #1;
    $display("mode 4 ring LED=%b", led);
    if (led !== 8'b0010_0000) errors = errors + 1;
    sw[2:0] = 3'd7; #1;
    $display("mode 7 lfsr LED=%h", led);
    if (led !== 8'h23) errors = errors + 1;
    sw[15] = 1; ticks(5); #1; // FREEZE for 5 ticks
    $display("frozen LED=%h", led);
    if (led !== 8'h23) errors = errors + 1;
    sw[15] = 0; sw[2:0] = 3'd3; #1;
    $display("mode 3 sec LED=%h", led);
    if (led !== 8'h05) errors = errors + 1;
    $display("7-seg: AN=%b gfedcba=%b", an,
    {cg, cf, ce, cd, cc, cb, ca});
    if ({cg,cf,ce,cd,cc,cb,ca} !== 7'b0110000)
    errors = errors + 1; // the digit "3"
    $display("done: %0d errors", errors);
    $finish;
end
endmodule