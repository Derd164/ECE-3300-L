`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/23/2026 11:42:22 AM
// Design Name: 
// Module Name: sec_counter_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module sec_counter_tb;
    reg clk, rst, en;
    wire [3:0] ones, tens;
    wire co;
    integer i, errors, wraps;
    sec_counter dut (.clk(clk), .rst(rst), .en(en),
    .ones(ones), .tens(tens), .co(co));
    always #5 clk = ~clk;
initial begin
    clk = 0; errors = 0; wraps = 0;
    rst = 1; en = 1; @(posedge clk); #1;
    rst = 0;
    for (i = 1; i <= 125; i = i + 1) begin
        if (co) wraps = wraps + 1; // a 59 -> 00 moment
        @(posedge clk); #1;
        if (i==9 || i==10 || i==59 || i==60)
        $display("tick %0d %0d%0d", i, tens, ones);
        if (tens !== (i % 60) / 10) errors = errors + 1;
        if (ones !== (i % 60) % 10) errors = errors + 1;
    end
    $display("wraps: %0d (expect 2)", wraps);
    if (wraps !== 2) errors = errors + 1;
    $display("done: %0d errors", errors);
    $finish;
end
endmodule