`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/23/2026 11:55:34 AM
// Design Name: 
// Module Name: ring_counter_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module ring_counter_tb;
    reg clk, rst, en;
    wire [3:0] q;
    integer i, errors;
    ring_counter #(.N(4)) dut (.clk(clk), .rst(rst),
    .en(en), .q(q));
    always #5 clk = ~clk;
initial begin
    clk = 0; errors = 0;
    rst = 1; en = 1; @(posedge clk); #1;
    $display("reset q=%b", q);
    if (q !== 4'b0001) errors = errors + 1;
    rst = 0;
    for (i = 1; i <= 12; i = i + 1) begin
        @(posedge clk); #1;
        if (i <= 4) $display("tick %0d q=%b", i, q);
        // golden: a 1 shifted left (i mod 4) places
        if (q !== (4'b0001 << (i % 4))) errors = errors + 1;
    end
    $display("done: %0d errors", errors);
    $finish;
end
endmodule