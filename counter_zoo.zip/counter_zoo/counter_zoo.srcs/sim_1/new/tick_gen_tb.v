`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/23/2026 12:15:43 PM
// Design Name: 
// Module Name: tick_gen_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module tick_gen_tb;
    reg clk, rst;
    wire tick;
    integer i, errors, ticks;
    // TICK_MAX = 4 here, not 25 M: same logic, 40 clocks
    tick_gen #(.TICK_MAX(4)) dut (.clk(clk), .rst(rst),
    .tick(tick));
    always #5 clk = ~clk;
initial begin
    clk = 0; errors = 0; ticks = 0;
    rst = 1; @(posedge clk); #1;
    rst = 0;
    for (i = 1; i <= 40; i = i + 1) begin
        @(posedge clk); #1;
        if (i <= 8) $display("clock %0d tick=%b", i, tick);
        if (tick) ticks = ticks + 1;
        // golden: tick on every 4th clock
        if (tick !== (i % 4 == 0)) errors = errors + 1;
    end
    $display("40 clocks: %0d ticks (expect 10)", ticks);
    if (ticks !== 10) errors = errors + 1;
    $display("done: %0d errors", errors);
    $finish;
end
endmodule