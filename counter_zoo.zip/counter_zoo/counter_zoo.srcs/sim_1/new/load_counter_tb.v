`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/23/2026 11:47:10 AM
// Design Name: 
// Module Name: load_counter_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module load_counter_tb;
    reg clk, rst, load, en;
    reg [3:0] d;
    wire [3:0] q;
    integer errors;
    load_counter #(.N(4)) dut (.clk(clk), .rst(rst),
    .load(load), .d(d), .en(en), .q(q));
    always #5 clk = ~clk;
    task step(input [3:0] want, input [8*12-1:0] why);
    begin
        @(posedge clk); #1;
        $display("%s q=%0d", why, q);
        if (q !== want) errors = errors + 1;
    end
    endtask
initial begin
    clk = 0; errors = 0; d = 4'd12;
    rst = 1; load = 1; en = 1; step(0, "rst > load ");
    rst = 0; step(12, "load d=12 ");
    load = 0; step(13, "count ");
    step(14, "count ");
    step(15, "count ");
    step(0, "wrap ");
    load = 1; d = 4'd7; step(7, "load > en ");
    load = 0; en = 0; step(7, "en=0 hold ");
    $display("done: %0d errors", errors);
    $finish;
end
endmodule