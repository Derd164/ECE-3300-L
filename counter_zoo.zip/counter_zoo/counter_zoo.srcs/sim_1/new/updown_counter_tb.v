`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/21/2026 12:51:16 PM
// Design Name: 
// Module Name: updown_counter_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module updown_counter_tb;
    reg clk, rst, en, dir;
    wire [3:0] q;
    integer i, errors, model;
    updown_counter #(.N(4)) dut (.clk(clk), .rst(rst),
    .en(en), .dir(dir), .q(q));
    always #5 clk = ~clk;
initial begin
    clk = 0; errors = 0; model = 0;
    rst = 1; en = 1; dir = 1; @(posedge clk); #1;
    rst = 0;
    for (i = 1; i <= 8; i = i + 1) begin
        dir = (i <= 3); // 3 up, then 5 down
        @(posedge clk); #1;
        if (dir) model = (model + 1) % 16;
        else model = (model + 15) % 16; // = -1
        $display("tick %0d dir=%b q=%0d", i, dir, q);
        if (q !== model) errors = errors + 1;
    end
    $display("done: %0d errors", errors);
    $finish;
end
endmodule