`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/23/2026 12:09:44 PM
// Design Name: 
// Module Name: lfsr8_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module lfsr8_tb;
    reg clk, rst, en;
    wire [7:0] q;
    reg seen [0:255];
    integer i, errors, period;
    lfsr8 dut (.clk(clk), .rst(rst), .en(en), .q(q));
    always #5 clk = ~clk;
initial begin
    clk = 0; errors = 0; period = 0;
    for (i = 0; i < 256; i = i + 1) seen[i] = 0;
    rst = 1; en = 1; @(posedge clk); #1;
    rst = 0; seen[q] = 1;
    $display("seed q=%h", q);
    for (i = 1; i <= 300; i = i + 1) begin
        @(posedge clk); #1;
        if (i <= 4) $display("tick %0d q=%h", i, q);
        if (q === 8'h00) errors = errors + 1; // never 0
        if (q === 8'h01 && period == 0)
        period = i; // seed again
        else if (period == 0 && seen[q])
        errors = errors + 1; // early repeat
        seen[q] = 1;
    end
    $display("period = %0d (expect 255)", period);
    if (period !== 255) errors = errors + 1;
    $display("done: %0d errors", errors);
    $finish;
end
endmodule