`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/23/2026 11:51:46 AM
// Design Name: 
// Module Name: sat_counter_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module sat_counter_tb;
    reg clk, rst, en;
    wire [3:0] q;
    integer i, errors;
    sat_counter #(.N(4)) dut (.clk(clk), .rst(rst),
    .en(en), .q(q));
    always #5 clk = ~clk;
initial begin
    clk = 0; errors = 0;
    rst = 1; en = 1; @(posedge clk); #1;
    rst = 0;
    for (i = 1; i <= 20; i = i + 1) begin
        @(posedge clk); #1;
        if (i >= 14 && i <= 17)
        $display("tick %0d q=%0d", i, q);
        // golden: min(i, 15)
        if (q !== ((i < 15) ? i : 15)) errors = errors + 1;
    end
    rst = 1; @(posedge clk); #1; // corner: reset works
    $display("reset q=%0d", q);
    if (q !== 4'd0) errors = errors + 1;
    $display("done: %0d errors", errors);
    $finish;
    end
endmodule