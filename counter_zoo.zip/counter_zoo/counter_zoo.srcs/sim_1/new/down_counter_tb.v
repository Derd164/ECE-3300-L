`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/21/2026 12:44:46 PM
// Design Name: 
// Module Name: down_counter_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module down_counter_tb;
    reg clk, rst, en;
    wire [3:0] q;
    integer i, errors;
    down_counter #(.N(4)) dut (.clk(clk), .rst(rst),
    .en(en), .q(q));
    always #5 clk = ~clk;
initial begin
    clk = 0; errors = 0;
    rst = 1; en = 1; @(posedge clk); #1; // corner: reset
    $display("reset q=%0d", q);
    if (q !== 4'd0) errors = errors + 1;
    rst = 0;
    for (i = 1; i <= 20; i = i + 1) begin // sweep
        @(posedge clk); #1;
        if (i <= 3) $display("tick %0d q=%0d", i, q);
        if (q !== (16 - i % 16) % 16) errors = errors + 1;
    end
    $display("done: %0d errors", errors);
    $finish;
end
endmodule