`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/23/2026 12:00:20 PM
// Design Name: 
// Module Name: johnson_counter_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module johnson_counter_tb;
    reg clk, rst, en;
    wire [3:0] q;
    reg [3:0] want;
    integer i, k, errors;
    johnson_counter #(.N(4)) dut (.clk(clk), .rst(rst),
    .en(en), .q(q));
    always #5 clk = ~clk;
initial begin
    clk = 0; errors = 0;
    rst = 1; en = 1; @(posedge clk); #1;
    $display("reset q=%b", q);
    rst = 0;
    for (i = 1; i <= 16; i = i + 1) begin
        @(posedge clk); #1;
        k = i % 8; // 2N = 8 states
        if (k <= 4) want = (4'b0001 << k) - 1; // fill
        else want = 4'b1111 << (k - 4); // empty
        if (i <= 8) $display("tick %0d q=%b", i, q);
        if (q !== want) errors = errors + 1;
    end
    $display("done: %0d errors", errors);
    $finish;
end
endmodule