`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/23/2026 12:05:03 PM
// Design Name: 
// Module Name: gray_counter_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module gray_counter_tb;
    reg clk, rst, en;
    wire [3:0] g;
    reg [3:0] prev, diff;
    reg seen [0:15];
    integer i, errors, flips;
    gray_counter #(.N(4)) dut (.clk(clk), .rst(rst),
    .en(en), .g(g));
    always #5 clk = ~clk;
initial begin
    clk = 0; errors = 0;
    for (i = 0; i < 16; i = i + 1) seen[i] = 0;
    rst = 1; en = 1; @(posedge clk); #1;
    rst = 0; prev = g; seen[g] = 1;
    $display("reset g=%b", g);
    for (i = 1; i <= 16; i = i + 1) begin // lap + wrap
        @(posedge clk); #1;
        diff = g ^ prev; // flipped bits
        flips = diff[0]+diff[1]+diff[2]+diff[3];
        if (i <= 4 || i >= 15)
        $display("tick %0d g=%b flips=%0d", i, g, flips);
        if (flips !== 1) errors = errors + 1; // rule 1
        if (i < 16 && seen[g]) errors = errors + 1; // 2
        seen[g] = 1; prev = g;
    end
    $display("done: %0d errors", errors);
    $finish;
end
endmodule