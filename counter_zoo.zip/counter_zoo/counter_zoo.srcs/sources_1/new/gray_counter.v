`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/23/2026 12:03:34 PM
// Design Name: 
// Module Name: gray_counter
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// gray_counter.v -- ONE bit changes per step
module gray_counter #(
parameter N = 4
)(
    input clk,
    input rst,
    input en,
    output [N-1:0] g // Gray-code output
);
reg [N-1:0] b; // plain binary counter
always @(posedge clk) begin
    if (rst)
    b <= {N{1'b0}};
    else if (en)
    b <= b + 1'b1;
end
assign g = b ^ (b >> 1); // binary -> Gray
endmodule