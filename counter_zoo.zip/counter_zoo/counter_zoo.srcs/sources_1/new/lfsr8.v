`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/23/2026 12:08:45 PM
// Design Name: 
// Module Name: lfsr8
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// lfsr8.v -- 8-bit LFSR: all 255 non-zero values
module lfsr8 (
    input clk,
    input rst,
    input en,
    output reg [7:0] q
);
wire fb = q[7] ^ q[5] ^ q[4] ^ q[3]; // the taps
always @(posedge clk) begin
    if (rst)
    q <= 8'h01; // seed: never 0
    else if (en)
    q <= {q[6:0], fb}; // shift left, add fb
end
endmodule