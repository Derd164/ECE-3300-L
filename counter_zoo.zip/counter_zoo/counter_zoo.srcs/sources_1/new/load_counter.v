`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/23/2026 11:45:37 AM
// Design Name: 
// Module Name: load_counter
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// load_counter.v -- up counter that can jump to d
module load_counter #(
    parameter N = 4
)(
    input clk,
    input rst,
    input load, // 1 = copy d into q
    input [N-1:0] d,
    input en,
    output reg [N-1:0] q
);
always @(posedge clk) begin
    if (rst)
    q <= {N{1'b0}}; // priority 1: reset
    else if (load)
    q <= d; // priority 2: load
    else if (en)
    q <= q + 1'b1; // priority 3: count
end
endmodule