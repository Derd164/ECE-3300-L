`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/23/2026 11:34:24 AM
// Design Name: 
// Module Name: modn_counter
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// modn_counter.v -- 0 .. MOD-1, then back to 0
    module modn_counter #(
    parameter N = 4, // bits
    parameter MOD = 10 // 10 = decade (BCD)
)(
    input clk,
    input rst,
    input en,
    output reg [N-1:0] q,
    output co // carry out: wraps now
);
assign co = en & (q == MOD-1);
always @(posedge clk) begin
    if (rst)
    q <= {N{1'b0}};
    else if (en) begin
        if (q == MOD-1)
        q <= {N{1'b0}}; // last value: wrap
        else
        q <= q + 1'b1;
    end
end
endmodule