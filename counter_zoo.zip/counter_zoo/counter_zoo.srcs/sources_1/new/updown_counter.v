`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/21/2026 12:48:42 PM
// Design Name: 
// Module Name: updown_counter
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// updown_counter.v -- dir = 1 up, dir = 0 down
module updown_counter #(
    parameter N = 4
)(
    input clk,
    input rst,
    input en,
    input dir, // 1 = up, 0 = down
    output reg [N-1:0] q
);
always @(posedge clk) begin
    if (rst)
    q <= {N{1'b0}};
    else if (en) begin
        if (dir)
        q <= q + 1'b1; // up
        else
        q <= q - 1'b1; // down
    end
end
endmodule