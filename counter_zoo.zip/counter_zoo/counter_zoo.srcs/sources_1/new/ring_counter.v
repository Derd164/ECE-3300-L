`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/23/2026 11:54:29 AM
// Design Name: 
// Module Name: ring_counter
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// ring_counter.v -- one 1 travels around the ring
module ring_counter #(
    parameter N = 4
)(
    input clk,
    input rst,
    input en,
    output reg [N-1:0] q
);
always @(posedge clk) begin
    if (rst)
    q <= {{(N-1){1'b0}}, 1'b1}; // 0001
    else if (en)
    q <= {q[N-2:0], q[N-1]}; // rotate left
end
endmodule