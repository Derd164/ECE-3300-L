`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/23/2026 12:13:51 PM
// Design Name: 
// Module Name: tick_gen
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// tick_gen.v -- 1-clock pulse every TICK_MAX clocks
module tick_gen #(
    parameter TICK_MAX = 25_000_000 // 4 per second
)(
    input clk,
    input rst,
    output reg tick
);
reg [31:0] cnt;
always @(posedge clk) begin
    if (rst) begin
        cnt <= 32'd0;
        tick <= 1'b0;
    end else if (cnt == TICK_MAX-1) begin
        cnt <= 32'd0;
        tick <= 1'b1; // the one-clock pulse
    end else begin
        cnt <= cnt + 1'b1;
        tick <= 1'b0;
        end
end
endmodule