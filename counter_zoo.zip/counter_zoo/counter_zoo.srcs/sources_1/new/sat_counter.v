`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/23/2026 11:49:53 AM
// Design Name: 
// Module Name: sat_counter
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// sat_counter.v -- climbs to the top and STAYS
module sat_counter #(
parameter N = 4
)(
    input clk,
    input rst,
    input en,
    output reg [N-1:0] q
);
always @(posedge clk) begin
    if (rst)
    q <= {N{1'b0}};
    else if (en && (q != {N{1'b1}}))
    q <= q + 1'b1; // only if not at max
end
endmodule