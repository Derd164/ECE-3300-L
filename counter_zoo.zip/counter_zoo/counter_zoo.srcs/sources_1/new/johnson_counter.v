`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/23/2026 11:59:03 AM
// Design Name: 
// Module Name: johnson_counter
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// johnson_counter.v -- ring + ONE inverter: 2N states
module johnson_counter #(
    parameter N = 4
)(
    input clk,
    input rst,
    input en,
    output reg [N-1:0] q
);
always @(posedge clk) begin
    if (rst)
    q <= {N{1'b0}}; // 0000
    else if (en)
    q <= {q[N-2:0], ~q[N-1]}; // NOT fed back
end
endmodule