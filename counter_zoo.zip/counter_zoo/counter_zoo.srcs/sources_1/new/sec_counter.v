`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/23/2026 11:39:51 AM
// Design Name: 
// Module Name: sec_counter
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// sec_counter.v -- two BCD digits: 00, 01 .. 59, 00
module sec_counter (
    input clk,
    input rst,
    input en,
    output [3:0] ones,
    output [3:0] tens,
    output co // pulses on 59 -> 00
);
wire ones_co; // "ones just wrapped"
modn_counter #(.N(4), .MOD(10)) u_ones (.clk(clk),
.rst(rst), .en(en), .q(ones), .co(ones_co));
modn_counter #(.N(4), .MOD(6)) u_tens (.clk(clk),
.rst(rst), .en(ones_co), .q(tens), .co(co));
endmodule