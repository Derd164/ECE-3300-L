`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/23/2026 12:22:54 PM
// Design Name: 
// Module Name: counter_zoo_top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// counter_zoo_top.v -- 8 counters; SW[2:0] picks one
    module counter_zoo_top #(
    parameter TICK_MAX = 25_000_000 // 4 counts per second
)(
    input CLK100MHZ,
    input CPU_RESETN, // red button, active-LOW
    input [15:0] SW,
    output [7:0] LED,
    output [7:0] AN,
    output CA, CB, CC, CD, CE, CF, CG, DP
);
wire clk = CLK100MHZ; // short name, 100 MHz
// ---- power-on reset: saturating, holds rst 15 clocks
reg [3:0] por = 4'd0;
always @(posedge clk)
if (por != 4'hF) por <= por + 1'b1;
wire rst = ~CPU_RESETN | (por != 4'hF);
wire tick;
wire en = tick & ~SW[15]; // SW15 up = FREEZE
wire [2:0] mode = SW[2:0];
wire dir = SW[3]; // mode 2: 1 up, 0 down
tick_gen #(.TICK_MAX(TICK_MAX)) u_tick (.clk(clk),
.rst(rst), .tick(tick));
// ---- the eight counters, all running at once
wire [7:0] q_up, q_dn, q_ud, q_ring, q_john, q_gray, q_lfsr;
wire [3:0] ones, tens;
wire sec_co;
up_counter #(.N(8)) c0 (.clk(clk), .rst(rst), .en(en), .q(q_up));
down_counter #(.N(8)) c1 (.clk(clk), .rst(rst), .en(en), .q(q_dn));
updown_counter #(.N(8)) c2 (.clk(clk), .rst(rst), .en(en), .dir(dir), .q(q_ud));
sec_counter c3 (.clk(clk), .rst(rst), .en(en),
.ones(ones), .tens(tens), .co(sec_co));
ring_counter #(.N(8)) c4 (.clk(clk), .rst(rst), .en(en), .q(q_ring));
johnson_counter #(.N(8)) c5 (.clk(clk), .rst(rst), .en(en), .q(q_john));
gray_counter #(.N(8)) c6 (.clk(clk), .rst(rst), .en(en), .g(q_gray));
lfsr8 c7 (.clk(clk), .rst(rst), .en(en), .q(q_lfsr));
// ---- the chooser: 8-way mux feeds the LEDs
reg [7:0] show;
always @(*) begin
    case (mode)
        3'd0: show = q_up;
        3'd1: show = q_dn;
        3'd2: show = q_ud;
        3'd3: show = {tens, ones};
        3'd4: show = q_ring;
        3'd5: show = q_john;
        3'd6: show = q_gray;
        3'd7: show = q_lfsr;
        default: show = 8'h00;
    endcase
end
assign LED = show;
// ---- 7-segment: rightmost digit = mode number
wire [6:0] seg;
seg7_decoder u_seg (.x({1'b0, mode}), .seg(seg));
assign {CG, CF, CE, CD, CC, CB, CA} = seg;
assign DP = 1'b1; // dot OFF
assign AN = 8'b1111_1110; // only digit 0 ON
endmodule