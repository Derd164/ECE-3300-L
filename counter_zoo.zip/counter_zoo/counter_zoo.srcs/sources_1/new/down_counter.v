`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/21/2026 12:40:45 PM
// Design Name: 
// Module Name: down_counter
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// down_counter.v -- ... 2, 1, 0, then wraps to all 1s
module down_counter #(
parameter N = 4
)(
    input clk,
    input rst,
    input en,
    output reg [N-1:0] q
);
    always @(posedge clk) begin
        if (rst)
        q <= {N{1'b0}};
        else if (en)
        q <= q - 1'b1; // DOWN: the only change
    end
endmodule