`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/21/2026 12:32:25 PM
// Design Name: 
// Module Name: up_counter
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module up_counter #(
parameter N = 4 // number of bits
)(
    input clk,
    input rst, // sync, active-high
    input en, // 1 = count
    output reg [N-1:0] q
);
    always @(posedge clk) begin
    if (rst)
    q <= {N{1'b0}}; // back to zero
    else if (en)
    q <= q + 1'b1; // one step UP
end
endmodule