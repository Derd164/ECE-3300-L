`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/02/2026 12:11:23 PM
// Design Name: 
// Module Name: full_adder
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module full_adder(
    input a, b, cin,
    output sum, cout
);
wire w1, w2, w3, w4, w5;
xor g1 (w1, a, b); // w1 = a ^ b
xor g2 (sum, w1, cin); // sum = odd count
and g3 (w2, a, b); // pair vote 1
and g4 (w3, a, cin); // pair vote 2
and g5 (w4, b, cin); // pair vote 3
or g6 (w5, w2, w3); // collect votes...
or g7 (cout, w5, w4); // ...majority wins

endmodule