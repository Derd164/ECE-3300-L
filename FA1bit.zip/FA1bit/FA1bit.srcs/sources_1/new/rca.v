`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/02/2026 12:15:51 PM
// Design Name: 
// Module Name: rca
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module rca #(
    parameter N = 4 // public knob: the width
)(
    input [N-1:0] a, b,
    input cin,
    output [N-1:0] sum,
    output cout
    );
    localparam CARRYW = N + 1; // derived, private
    wire [CARRYW-1:0] c; // the carry chain
    assign c[0] = cin; // seed the chain
    genvar i;
    generate
    for (i = 0; i < N; i = i + 1) begin : ADD
    full_adder fa (
    .a(a[i]), .b(b[i]), .cin(c[i]),
    .sum(sum[i]), .cout(c[i+1])
    );
    end
    endgenerate
    assign cout = c[N]; // last carry leaves
endmodule