`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/02/2026 12:20:46 PM
// Design Name: 
// Module Name: rca_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module rca_tb; // no ports!
localparam N = 4;
reg [N-1:0] a, b; // we drive these
reg cin;
wire [N-1:0] sum; // we watch these
wire cout;
integer i, j, errors;
reg [N:0] expected; // N+1 bits: 15+15=30
rca #(.N(N)) dut (
    .a(a), .b(b), .cin(cin),
    .sum(sum), .cout(cout)
);
initial begin
    cin = 0; errors = 0;
    for (i = 0; i < 16; i = i + 1)
        for (j = 0; j < 16; j = j + 1) begin
            a = i; b = j;
            #10; // let it settle
            expected = i + j;
            if ({cout, sum} !== expected) begin
            errors = errors + 1;
            $display("FAIL %0d+%0d got %0d",
            i, j, {cout, sum});
        end
    end
$display("done: %0d errors", errors);
$finish;
end
endmodule