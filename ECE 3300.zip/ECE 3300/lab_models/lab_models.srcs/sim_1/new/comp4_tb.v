`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/15/2026 04:07:08 PM
// Design Name: 
// Module Name: comp4_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module comp4_tb;
    reg [3:0] a, b;
    wire eq, gt, lt;
    integer i, j, errors;
    comp4 dut (.a(a), .b(b), .eq(eq), .gt(gt), .lt(lt));
    initial begin
        errors = 0;
        for (i = 0; i < 16; i = i + 1)
            for (j = 0; j < 16; j = j + 1) begin
                a = i; b = j;
                #10;
                if ({eq, gt, lt} !== {i == j, i > j, i < j}) begin
                errors = errors + 1;
                $display("FAIL %0d vs %0d: eq=%b gt=%b lt=%b", i, j, eq, gt, lt);
                end
                if (eq + gt + lt != 1) begin // exactly ONE must be high
                errors = errors + 1;
                $display("FAIL %0d vs %0d: not one-hot", i, j);
            end
        end
    $display("done: %0d errors", errors);
    $finish;
    end
endmodule
