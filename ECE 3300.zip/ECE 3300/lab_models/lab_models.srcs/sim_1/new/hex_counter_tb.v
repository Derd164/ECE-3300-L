`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/16/2026 11:51:08 AM
// Design Name: 
// Module Name: hex_counter_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module hex_counter_tb;
    reg clk, btnc;
    wire [6:0] seg;
    wire dp;
    wire [7:0] an;
    wire [3:0] led;
    integer i, errors;
    // TICK_MAX shrunk from 50 million to 4: same logic, watchable sim
hex_counter #(.TICK_MAX(4)) dut (
    .CLK100MHZ(clk), .BTNC(btnc), .SEG(seg), .DP(dp), .AN(an), .LED(led)
);
always #5 clk = ~clk;
initial begin
    clk = 0; errors = 0;
    btnc = 1; @(posedge clk); #1; btnc = 0; // pulse reset
    if (led !== 0) begin errors = errors + 1; $display("FAIL reset"); end
    if (an !== 8'b1111_1110) begin errors = errors + 1; $display("FAIL AN"); end
    if (dp !== 1'b1) begin errors = errors + 1; $display("FAIL DP"); end
    for (i = 1; i <= 3; i = i + 1) begin
        repeat (4) @(posedge clk); #1; // one full tick period
        $display("after tick %0d: LED=%0d SEG=%b", i, led, seg);
        if (led !== i[3:0]) begin
            errors = errors + 1;
            $display("FAIL: expected %0d", i);
        end
    end
    $display("done: %0d errors", errors);
    $finish;
end
endmodule
