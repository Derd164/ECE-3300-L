`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/16/2026 11:45:27 AM
// Design Name: 
// Module Name: shift_demo_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module shift_demo_tb; // WHY sequential logic uses <=
    reg clk, din;
    reg g1, g2, g3; // "good" chain, built with <=
    reg b1, b2, b3; // "bad" chain, built with =
    always #5 clk = ~clk;
always @(posedge clk) begin // three flip-flops in a row
    g1 <= din; // all three read OLD values,
    g2 <= g1; // then all three update together
    g3 <= g2;
end
always @(posedge clk) begin // LOOKS the same...
    b1 = din; // ...but b1 changes IMMEDIATELY,
    b2 = b1; // so b2 copies the NEW b1,
    b3 = b2; // and the "chain" collapses to a wire
end
initial begin
    clk = 0; din = 0; g1 = 0; g2 = 0; g3 = 0; b1 = 0; b2 = 0; b3 = 0;
    din = 1; // feed a single 1 into both chains
    @(posedge clk); #1; din = 0;
    $display("after edge 1: <= chain g=%b%b%b = chain b=%b%b%b", g1,g2,g3,
    b1,b2,b3);
    @(posedge clk); #1;
    $display("after edge 2: <= chain g=%b%b%b = chain b=%b%b%b", g1,g2,g3,
    b1,b2,b3);
    @(posedge clk); #1;
    $display("after edge 3: <= chain g=%b%b%b = chain b=%b%b%b", g1,g2,g3,
    b1,b2,b3);
    $finish;
end
endmodule
