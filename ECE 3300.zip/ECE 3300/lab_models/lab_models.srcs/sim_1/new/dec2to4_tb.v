`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/15/2026 04:00:49 PM
// Design Name: 
// Module Name: dec2to4_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module dec2to4_tb;
    reg [1:0] sel;
    reg en;
    wire [3:0] y;
    integer i, errors;
    reg [3:0] expected;
    dec2to4 dut (.sel(sel), .en(en), .y(y));
    initial begin
        errors = 0;
        for (i = 0; i < 8; i = i + 1) begin
            {en, sel} = i;
            #10;
            expected = en ? (4'b0001 << sel) : 4'b0000;
            if (y !== expected) begin
                errors = errors + 1;
                $display("FAIL en=%b sel=%b got %b", en, sel, y);
            end
        end
        $display("done: %0d errors", errors);
        $finish;
    end
endmodule
