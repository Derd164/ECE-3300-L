`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/16/2026 11:40:36 AM
// Design Name: 
// Module Name: count4_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module count4_tb;
    localparam N = 4;
    reg clk, rst, en;
    wire [N-1:0] q;
    integer i, errors;
    reg [N-1:0] model; // software copy of the counter
    count4 #(.N(N)) dut (.clk(clk), .rst(rst), .en(en), .q(q));
    always #5 clk = ~clk;
initial begin
    clk = 0; errors = 0; model = 0;
    rst = 1; en = 0; @(posedge clk); #1;
    if (q !== 0) begin errors = errors + 1; $display("FAIL reset"); end
    rst = 0; en = 1;
    for (i = 0; i < 20; i = i + 1) begin // 20 > 16: crosses the wrap
        @(posedge clk); #1;
        model = model + 1;
        if (q !== model) begin
            errors = errors + 1;
            $display("FAIL step %0d: q=%0d model=%0d", i, q, model);
        end
    end
    en = 0; @(posedge clk); #1; // freeze check
    if (q !== model) begin errors = errors + 1; $display("FAIL freeze"); end
    $display("counter is at %0d after 20 ticks (20 mod 16 = 4)", q);
    $display("done: %0d errors", errors);
    $finish;
end
endmodule
