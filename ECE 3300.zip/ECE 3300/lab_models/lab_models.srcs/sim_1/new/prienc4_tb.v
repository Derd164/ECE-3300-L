`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/15/2026 04:43:09 PM
// Design Name: 
// Module Name: prienc4_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module prienc4_tb;
reg [3:0] req;
wire [1:0] code;
wire valid;
integer i, errors;
reg [1:0] exp_code;
reg exp_valid;
prienc4 dut (.req(req), .code(code), .valid(valid));
initial begin
    errors = 0;
    for (i = 0; i < 16; i = i + 1) begin
        req = i;
        #10;
        exp_valid = (req != 0);
        exp_code = req[3] ? 2'd3 : req[2] ? 2'd2 :
        req[1] ? 2'd1 : 2'd0;
        if (valid !== exp_valid ||
            (valid && code !== exp_code)) begin
            errors = errors + 1;
            $display("FAIL req=%b code=%b valid=%b", req, code, valid);
        end
    end
    $display("done: %0d errors", errors);
    $finish;
    end
endmodule
