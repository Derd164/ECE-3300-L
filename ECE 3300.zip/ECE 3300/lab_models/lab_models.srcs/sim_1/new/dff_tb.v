`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/16/2026 11:36:07 AM
// Design Name: 
// Module Name: dff_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module dff_tb;
    reg clk, rst, en, d;
    wire q;
    integer errors;
    dff dut (.clk(clk), .rst(rst), .en(en), .d(d), .q(q));
    always #5 clk = ~clk; // 10 ns period, forever
initial begin
    clk = 0; errors = 0;
    rst = 1; en = 0; d = 0; // test 1: reset
    @(posedge clk); #1;
    if (q !== 0) begin errors = errors + 1; $display("FAIL reset"); end
    rst = 0; en = 1; d = 1; // test 2: capture a 1
    @(posedge clk); #1;
    if (q !== 1) begin errors = errors + 1; $display("FAIL capture"); end
    en = 0; d = 0; // test 3: en=0 -> q must NOT follow d
    @(posedge clk); #1;
    if (q !== 1) begin errors = errors + 1; $display("FAIL hold"); end
    en = 1; rst = 1; d = 1; // test 4: reset beats enable
    @(posedge clk); #1;
    if (q !== 0) begin errors = errors + 1; $display("FAIL rst priority"); end
    $display("done: %0d errors", errors);
    $finish;
end
endmodule
