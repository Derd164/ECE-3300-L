`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/15/2026 03:40:42 PM
// Design Name: 
// Module Name: ops_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module ops_tb; // no hardware -- a printing lab
    reg [3:0] a, b;
    initial begin
        a = 4'b1100; b = 4'b1010; // a = 12, b = 10 -- memorize these
        $display("a=%b b=%b", a, b);
        $display("--- bitwise: column by column ---");
        $display("a & b = %b", a & b);
        $display("a | b = %b", a | b);
        $display("a ^ b = %b", a ^ b);
        $display("~a = %b", ~a);
        $display("--- reduction: one vector folds to ONE bit ---");
        $display("&a = %b |a = %b ^a = %b", &a, |a, ^a);
        $display("--- logical: whole vector as true/false ---");
        $display("a && b = %b a || b = %b !a = %b", a && b, a || b, !a);
        $display("--- arithmetic ---");
        $display("a + b = %0d a - b = %0d a * b = %0d", a + b, a - b, a * b);
        $display("--- the width trap: 12+10 is NOT 6. fix the width: ---");
        $display("{1'b0,a} + b = %0d full product = %0d", {1'b0, a} + b, {4'b0, a} * b);
        $display("--- relational and equality ---");
        $display("a > b = %b a == b = %b a != b = %b", a > b, a == b, a != b);
        $display("--- shifts ---");
        $display("a >> 1 = %b a << 1 = %b", a >> 1, a << 1);
        $display("--- concatenation and replication ---");
        $display("{a, b} = %b", {a, b});
        $display("{2{a}} = %b", {2{a}});
        $display("{a[1:0], b[3:2]} = %b", {a[1:0], b[3:2]});
        $display("--- conditional (a 2:1 mux in one line) ---");
        $display("(a > b) ? a : b = %0d", (a > b) ? a : b);
        $finish;
    end
endmodule
