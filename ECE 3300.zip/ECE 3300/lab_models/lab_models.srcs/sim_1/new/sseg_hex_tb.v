`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/15/2026 04:50:39 PM
// Design Name: 
// Module Name: sseg_hex_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module sseg_hex_tb;
    reg [3:0] hex;
    wire [6:0] seg;
    integer i, errors, on_count;
    // how many segments each digit lights: 0..F
    reg [3:0] expected_on [0:15];
    sseg_hex dut (.hex(hex), .seg(seg));
initial begin
    expected_on[0]=6; expected_on[1]=2; expected_on[2]=5;
    expected_on[3]=5; expected_on[4]=4; expected_on[5]=5;
    expected_on[6]=6; expected_on[7]=3; expected_on[8]=7;
    expected_on[9]=6; expected_on[10]=6; expected_on[11]=5;
    expected_on[12]=4; expected_on[13]=5; expected_on[14]=5;
    expected_on[15]=4;
    errors = 0;
    for (i = 0; i < 16; i = i + 1) begin
        hex = i;
        #10;
        on_count = 7 - (seg[0]+seg[1]+seg[2]+seg[3]+seg[4]+seg[5]+seg[6]);
        $display("hex %h -> seg %b (%0d segments lit)", hex, seg, on_count);
        if (on_count != expected_on[i]) begin
            errors = errors + 1;
            $display("FAIL hex=%h lights %0d segments, expected %0d",
            hex, on_count, expected_on[i]);
        end
    end
    $display("done: %0d errors", errors);
    $finish;
end
endmodule
