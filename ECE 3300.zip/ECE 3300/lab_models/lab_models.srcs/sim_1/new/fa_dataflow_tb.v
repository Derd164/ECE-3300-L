`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/09/2026 01:53:31 PM
// Design Name: 
// Module Name: fa_dataflow_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module fa_dataflow_tb;
reg a, b, cin;
wire sum, cout;
integer i, errors;
reg [1:0] expected;
fa_dataflow dut (.a(a), .b(b), .cin(cin), .sum(sum), .cout(cout));
initial begin
    errors = 0;
    for (i = 0; i < 8; i = i + 1) begin
        {a, b, cin} = i; // 3 bits sweep 000..111
        #10;
        expected = a + b + cin;
        if ({cout, sum} !== expected) begin
            errors = errors + 1;
            $display("FAIL %b+%b+%b got %b%b", a, b, cin, cout, sum);
        end
    end
    $display("done: %0d errors", errors);
    $finish;
end
endmodule