`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/15/2026 04:33:00 PM
// Design Name: 
// Module Name: mux4_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module mux4_tb;
    reg [3:0] d;
    reg [1:0] sel;
    wire y_df, y_beh;
    integer i, j, errors;
    mux4 dut1 (.d(d), .sel(sel), .y(y_df)); // dataflow version
    mux4_beh dut2 (.d(d), .sel(sel), .y(y_beh)); // behavioral version
initial begin
    errors = 0;
    for (i = 0; i < 16; i = i + 1)
        for (j = 0; j < 4; j = j + 1) begin
            d = i; sel = j;
            #10;
            if (y_df !== d[sel] || y_beh !== d[sel]) begin
                errors = errors + 1;
                $display("FAIL d=%b sel=%b df=%b beh=%b", d, sel, y_df, y_beh);
            end
    end
    $display("done: %0d errors", errors);
    $finish;
end
endmodule
