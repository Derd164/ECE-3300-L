`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/15/2026 04:06:21 PM
// Design Name: 
// Module Name: comp4
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module comp4 (
    input [3:0] a, b,
    output eq, gt, lt
);
assign eq = (a == b);
assign gt = (a > b);
assign lt = (a < b);
endmodule
