`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/16/2026 11:49:48 AM
// Design Name: 
// Module Name: hex_counter
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module hex_counter #(
    parameter TICK_MAX = 50_000_000 // 100 MHz / 50M = 2 ticks/s
)(
    input CLK100MHZ,
    input BTNC, // press = reset
    output [6:0] SEG, // {CG..CA}, active low
    output DP, // decimal point, active low
    output [7:0] AN, // digit enables, active low
    output [3:0] LED
);
reg [25:0] tickcnt = 0; // 2^26 > 50M, so 26 bits fit
reg tick = 0;
always @(posedge CLK100MHZ) begin // the metronome
    if (tickcnt == TICK_MAX - 1) begin
        tickcnt <= 0;
        tick <= 1'b1; // one-cycle pulse
    end else begin
        tickcnt <= tickcnt + 1'b1;
        tick <= 1'b0;
    end
end
wire [3:0] value;
count4 #(.N(4)) counter ( // Example 8, reused as-is
.clk(CLK100MHZ), .rst(BTNC), .en(tick), .q(value)
);
sseg_hex digit (.hex(value), .seg(SEG)); // Example 6, reused as-is
assign DP = 1'b1; // dot OFF (0 would light it)
assign AN = 8'b1111_1110; // only rightmost digit on
assign LED = value; // same number in binary
endmodule
