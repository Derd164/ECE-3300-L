`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/15/2026 04:00:05 PM
// Design Name: 
// Module Name: dec2to4
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module dec2to4 (
    input [1:0] sel,
    input en,
    output [3:0] y
);
assign y = en ? (4'b0001 << sel) : 4'b0000; // shift the single 1
endmodule