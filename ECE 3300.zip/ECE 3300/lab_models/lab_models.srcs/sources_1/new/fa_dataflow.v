`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/09/2026 01:40:13 PM
// Design Name: 
// Module Name: fa_dataflow
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module fa_dataflow (
    input a, b, cin,
    output sum, cout
);
assign {cout, sum} = a + b + cin; // one line replaces seven gates
endmodule
