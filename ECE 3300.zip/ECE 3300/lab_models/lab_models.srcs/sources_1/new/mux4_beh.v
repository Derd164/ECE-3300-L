`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/15/2026 04:31:57 PM
// Design Name: 
// Module Name: mux4_beh
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module mux4_beh (
    input [3:0] d,
    input [1:0] sel,
    output reg y // written inside always => must be reg
);
always @(*) begin // recompute whenever ANY input changes
    case (sel)
        2'b00: y = d[0];
        2'b01: y = d[1];
        2'b10: y = d[2];
        default: y = d[3]; // default = no case forgotten, ever
        endcase
    end
endmodule