`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/16/2026 11:17:22 AM
// Design Name: 
// Module Name: dff
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module dff (
    input clk, rst, en, d,
    output reg q
);
always @(posedge clk) begin // only the clock edge matters
    if (rst) q <= 1'b0; // synchronous reset wins
    else if (en) q <= d; // capture only when enabled
    // no else: q keeps its value -- that is the MEMORY
end
endmodule
