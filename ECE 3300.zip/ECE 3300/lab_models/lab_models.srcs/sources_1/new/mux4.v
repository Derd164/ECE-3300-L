`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/15/2026 03:51:00 PM
// Design Name: 
// Module Name: mux4
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module mux4 (
    input [3:0] d, // four data inputs, one per bit
    input [1:0] sel, // which one gets through
    output y
);
assign y = (sel == 2'b00) ? d[0] :
            (sel == 2'b01) ? d[1] :
            (sel == 2'b10) ? d[2] :
            d[3]; // last one needs no question
endmodule
