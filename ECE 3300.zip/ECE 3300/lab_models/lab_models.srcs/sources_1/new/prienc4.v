`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/15/2026 04:42:15 PM
// Design Name: 
// Module Name: prienc4
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module prienc4 (
    input [3:0] req, // request lines, req[3] most important
    output reg [1:0] code, // number of the winner
    output reg valid // 0 = nobody asked
);
always @(*) begin
    if (req[3]) begin code = 2'd3; valid = 1'b1; end
    else if (req[2]) begin code = 2'd2; valid = 1'b1; end
    else if (req[1]) begin code = 2'd1; valid = 1'b1; end
    else if (req[0]) begin code = 2'd0; valid = 1'b1; end
    else begin code = 2'd0; valid = 1'b0; end
end
endmodule
