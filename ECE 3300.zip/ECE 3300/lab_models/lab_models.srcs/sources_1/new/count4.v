`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/16/2026 11:39:40 AM
// Design Name: 
// Module Name: count4
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module count4 #(
    parameter N = 4
)(
    input clk, rst, en,
    output reg [N-1:0] q
);
always @(posedge clk) begin
    if (rst) q <= {N{1'b0}}; // N zeros, any N
    else if (en) q <= q + 1'b1; // wraps naturally at 2^N
end
endmodule
