`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 08/31/2026 12:12:25 PM
// Design Name: 
// Module Name: mux2x1
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module mux2x1(
    input mux2x1_I0,
    input mux2x1_I1,
    input mux2x1_sel,
    output mux2x1_P
    );
    wire[2:0]mux2x1_tmp;
    not(mux2x1_tmp[0], mux2x1_sel);
    and(mux2x1_tmp[1], mux2x1_tmp[0], mux2x1_I0);
    and(mux2x1_tmp[2], mux2x1_sel, mux2x1_I1);
    or(mux2x1_P, mux2x1_tmp[1], mux2x1_tmp[2]);
endmodule
