`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 08/31/2026 12:29:59 PM
// Design Name: 
// Module Name: mux2x1_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module mux2x1_tb(

    );
reg mux2x1_I0, mux2x1_I1, mux2x1_sel;
wire mux2x1_P;
mux2x1 rtl_mux2x1( /*calling thing from design source, naming a new thing, 
and then assigning pins. .xyz's are the pins */
.mux2x1_I0(mux2x1_I0), /*calling mux2x1_IO from other code; assigning it to 
mux2x1_I0 declared here in the parenthesis. */
.mux2x1_I1(mux2x1_I1),
.mux2x1_sel(mux2x1_sel),
.mux2x1_P(mux2x1_P)
);

initial begin:Tst // :Tst is just a name. Can ditch it entirely or name it something else
    mux2x1_I0 = 0;
    mux2x1_I1 = 0;
    mux2x1_sel = 0;
    #30; // stay this way for 30ns then move on
    
    mux2x1_I0 = 1;
    mux2x1_I1 = 0;
    mux2x1_sel = 0;
    #30;
    
    mux2x1_I0 = 0;
    mux2x1_I1 = 1;
    mux2x1_sel = 0;
    #30;
    
    mux2x1_I0 = 1;
    mux2x1_I1 = 1;
    mux2x1_sel = 0;
    #30;
    
    mux2x1_I0 = 0;
    mux2x1_I1 = 0;
    mux2x1_sel = 1;
    #30;
    
    mux2x1_I0 = 1;
    mux2x1_I1 = 0;
    mux2x1_sel = 1;
    #30;
    
    mux2x1_I0 = 0;
    mux2x1_I1 = 1;
    mux2x1_sel = 1;
    #30;
    
    mux2x1_I0 = 1;
    mux2x1_I1 = 1;
    mux2x1_sel = 1;
    #30;
    $finish;
end
    
endmodule