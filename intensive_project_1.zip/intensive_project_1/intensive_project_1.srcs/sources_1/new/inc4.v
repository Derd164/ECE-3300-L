`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 02:08:36 PM
// Design Name: 
// Module Name: inc4
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// inc4.v -- add one; wrap raises a flag
module inc4 (
    input [3:0] a,
    output [3:0] y,
    output wrap
);
assign {wrap, y} = a + 4'd1;
endmodule