`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 03:21:01 PM
// Design Name: 
// Module Name: rippleN
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// rippleN.v -- N-bit ripple adder: generate writes the chain
module rippleN #(
    parameter N = 8
    )(
        input [N-1:0] a, b,
        input cin,
        output [N-1:0] sum,
        output cout
    );
        wire [N:0] c; // the carry wire between slices
        assign c[0] = cin;
        assign cout = c[N];
        genvar i;
        generate
        for (i = 0; i < N; i = i + 1) begin : slice
        full_adder_df fa (
        .a(a[i]), .b(b[i]), .cin(c[i]),
        .s(sum[i]), .co(c[i+1])
);
end
endgenerate
endmodule