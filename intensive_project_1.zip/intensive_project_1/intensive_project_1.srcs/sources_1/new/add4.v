`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 02:00:24 PM
// Design Name: 
// Module Name: add4
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// add4.v -- 4-bit adder; the 5-bit left side keeps the carry
module add4 (
    input [3:0] a, b,
    output [3:0] sum,
    output cout
);
assign {cout, sum} = a + b;
endmodule