`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 12:10:47 PM
// Design Name: 
// Module Name: busmux2_4
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// busmux2_4.v -- 2:1 mux, four bits wide: buses ride too
module busmux2_4 (
    input [3:0] a, b,
    input sel,
    output [3:0] y
);
assign y = sel ? b : a;
endmodule
