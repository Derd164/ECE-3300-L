`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 11:44:30 AM
// Design Name: 
// Module Name: mux2_df
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// mux2_df.v -- 2:1 mux, dataflow
module mux2_df (
    input a, b, sel,
    output y
);
assign y = sel ? b : a;
endmodule
