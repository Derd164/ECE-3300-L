`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 02:28:55 PM
// Design Name: 
// Module Name: flags4
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// flags4.v -- two status flags every ALU carries
module flags4 (
    input [3:0] a,
    output zero, // every bit is 0
    output neg // MSB, read as two's-complement sign
);
assign zero = ~|a;
assign neg = a[3];
endmodule