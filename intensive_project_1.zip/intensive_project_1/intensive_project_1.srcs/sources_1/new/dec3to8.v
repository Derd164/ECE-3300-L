`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 01:29:42 PM
// Design Name: 
// Module Name: dec3to8
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// dec3to8.v -- 3-to-8 decoder with enable, behavioral
module dec3to8 (
    input [2:0] sel,
    input en,
    output reg [7:0] y
);
always @(*) begin
    if (!en) y = 8'b0000_0000;
    else case (sel)
        3'd0: y = 8'b0000_0001;
        3'd1: y = 8'b0000_0010;
        3'd2: y = 8'b0000_0100;
        3'd3: y = 8'b0000_1000;
        3'd4: y = 8'b0001_0000;
        3'd5: y = 8'b0010_0000;
        3'd6: y = 8'b0100_0000;
        default: y = 8'b1000_0000;
    endcase
end
endmodule
