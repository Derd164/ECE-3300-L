`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 02:24:23 PM
// Design Name: 
// Module Name: parity_chk9
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// parity_chk9.v -- receiver side: flag a corrupted word
module parity_chk9 (
    input [7:0] d,
    input p, // the parity bit that traveled with d
    output err // 1 = the 9 bits do not add up
);
assign err = (^d) ^ p;
endmodule