`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 02:33:24 PM
// Design Name: 
// Module Name: swap_nib8
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// swap_nib8.v -- swap the two halves of a byte: pure wiring
module swap_nib8 (
    input [7:0] a,
    output [7:0] y
);
assign y = {a[3:0], a[7:4]};
endmodule