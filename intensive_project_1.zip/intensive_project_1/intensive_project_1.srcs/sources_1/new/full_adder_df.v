`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 01:52:47 PM
// Design Name: 
// Module Name: full_adder_df
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// full_adder_df.v -- full adder from its two equations
module full_adder_df (
    input a, b, cin,
    output s, co
);
assign s = a ^ b ^ cin;
assign co = (a & b) | (a & cin) | (b & cin);
endmodule