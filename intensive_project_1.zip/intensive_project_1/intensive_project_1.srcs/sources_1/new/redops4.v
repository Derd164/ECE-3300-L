`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/19/2026 03:27:25 PM
// Design Name: 
// Module Name: redops4
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// redops4.v -- reduction operators: a whole bus, one answer
module redops4 (
    input [3:0] a,
    output all_ones, // &a : every bit is 1
    output any_one, // |a : at least one bit is 1
    output parity // ^a : odd number of 1s
);
assign all_ones = &a;
assign any_one = |a;
assign parity = ^a;
endmodule
