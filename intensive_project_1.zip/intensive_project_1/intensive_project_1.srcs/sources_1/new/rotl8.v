`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 02:43:05 PM
// Design Name: 
// Module Name: rotl8
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// rotl8.v -- rotate left: nothing falls off, it comes back
module rotl8 (
    input [7:0] a,
    input [1:0] s,
    output reg [7:0] y
);
always @(*) begin
    case (s)
        2'd0: y = a;
        2'd1: y = {a[6:0], a[7]};
        2'd2: y = {a[5:0], a[7:6]};
    default: y = {a[4:0], a[7:5]};
    endcase
end
endmodule