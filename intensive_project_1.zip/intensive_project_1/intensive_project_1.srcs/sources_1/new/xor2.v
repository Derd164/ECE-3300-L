`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/19/2026 03:15:03 PM
// Design Name: 
// Module Name: xor2
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// xor2.v -- 2-input XOR: the difference detector
module xor2 (
    input a, b,
    output y
);
assign y = a ^ b;
endmodule
