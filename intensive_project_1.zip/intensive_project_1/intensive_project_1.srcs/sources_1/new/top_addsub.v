`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 03:58:11 PM
// Design Name: 
// Module Name: top_addsub
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// top_addsub.v -- addsub4 on the panel; SW15 picks the mode
module top_addsub (
    input [15:0] SW,
    output [15:0] LED
);
wire [3:0] r;
wire cout;
addsub4 u_as (.a(SW[3:0]), .b(SW[7:4]), .m(SW[15]),
.r(r), .cout(cout));
assign LED[3:0] = r;
assign LED[4] = cout;
assign LED[12:5] = 8'b0;
assign LED[13] = ~|r; // zero flag on the result
assign LED[14] = 1'b0;
assign LED[15] = SW[15]; // echo the mode back
endmodule