`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 01:46:16 PM
// Design Name: 
// Module Name: addr_dec
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// addr_dec.v -- address range decoder: hit for 4..11
module addr_dec (
    input [3:0] a,
    output sel
);
assign sel = (a >= 4'd4) && (a <= 4'd11);
endmodule