`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 02:52:07 PM
// Design Name: 
// Module Name: bin2gray4
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// bin2gray4.v -- Gray code: neighbors differ in one bit
module bin2gray4 (
    input [3:0] b,
    output [3:0] g
);
assign g = b ^ (b >> 1);
endmodule