`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 01:42:08 PM
// Design Name: 
// Module Name: onehot4_chk
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// onehot4_chk.v -- flag = exactly one request line is high
module onehot4_chk (
    input [3:0] r,
    output ok
);
// four 1-bit values, summed at 3 bits by the comparison
assign ok = ((r[0] + r[1] + r[2] + r[3]) == 3'd1);
endmodule