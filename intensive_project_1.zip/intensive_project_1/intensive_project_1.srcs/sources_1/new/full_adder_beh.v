`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 01:57:03 PM
// Design Name: 
// Module Name: full_adder_beh
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// full_adder_beh.v -- the same adder, one line of arithmetic
module full_adder_beh (
    input a, b, cin,
    output reg s, co
);
always @(*) begin
    {co, s} = a + b + cin;
end
endmodule