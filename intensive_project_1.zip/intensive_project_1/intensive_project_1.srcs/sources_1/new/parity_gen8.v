`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 02:17:58 PM
// Design Name: 
// Module Name: parity_gen8
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// parity_gen8.v -- even-parity bit for an 8-bit word
module parity_gen8 (
    input [7:0] d,
    output p // makes the 9-bit word hold an even 1-count
);
assign p = ^d;
endmodule