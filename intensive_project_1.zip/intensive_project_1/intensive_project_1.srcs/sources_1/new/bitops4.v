`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/19/2026 03:22:43 PM
// Design Name: 
// Module Name: bitops4
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// bitops4.v -- bitwise AND/OR/XOR/XNOR across a 4-bit bus
module bitops4 (
    input [3:0] a, b,
    output [3:0] y_and, y_or, y_xor, y_xnor
);
assign y_and = a & b;
assign y_or = a | b;
assign y_xor = a ^ b;
assign y_xnor = ~(a ^ b);
endmodule
