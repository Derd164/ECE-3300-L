`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 03:45:04 PM
// Design Name: 
// Module Name: parity_tree8
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// parity_tree8.v -- parity as a 3-level XOR tree, generated
module parity_tree8 (
        input [7:0] a,
        output p
    );
        wire [3:0] s1; // level 1: 8 -> 4
        wire [1:0] s2; // level 2: 4 -> 2
        genvar i;
        generate
            for (i = 0; i < 4; i = i + 1) begin : lvl1
            assign s1[i] = a[2*i] ^ a[2*i+1];
        end
        for (i = 0; i < 2; i = i + 1) begin : lvl2
        assign s2[i] = s1[2*i] ^ s1[2*i+1];
    end
endgenerate
assign p = s2[0] ^ s2[1]; // level 3: 2 -> 1
endmodule