`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 11:49:18 AM
// Design Name: 
// Module Name: mux2_beh
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// mux2_beh.v -- the same 2:1 mux, behavioral
module mux2_beh (
    input a, b, sel,
    output reg y
);
always @(*) begin
    if (sel) y = b;
    else y = a;
end
endmodule
