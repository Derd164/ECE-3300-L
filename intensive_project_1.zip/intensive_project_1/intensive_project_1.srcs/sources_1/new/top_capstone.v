`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 04:04:12 PM
// Design Name: 
// Module Name: top_capstone
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// top_capstone.v -- generate + compare + display, one chip
module top_capstone (
    input [7:0] SW,
    output [15:0] LED,
    output [6:0] SEG,
    output DP,
    output [7:0] AN
);
    wire [3:0] sum;
    wire cout, lt, eq, gt;
    rippleN #(.N(4)) u_add (
    .a(SW[3:0]), .b(SW[7:4]), .cin(1'b0),
    .sum(sum), .cout(cout)
);
    cmp4 u_cmp (.a(SW[3:0]), .b(SW[7:4]),
    .lt(lt), .eq(eq), .gt(gt));
    sseg_hex u_seg (.hex(sum), .seg(SEG));
    assign LED[3:0] = sum;
    assign LED[4] = cout;
    assign LED[12:5] = 8'b0;
    assign LED[15:13] = {gt, eq, lt};
    assign DP = 1'b1; // decimal point dark
    assign AN = 8'b1111_1110; // rightmost digit only
endmodule