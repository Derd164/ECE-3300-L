`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 03:15:54 PM
// Design Name: 
// Module Name: sseg_blank
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// sseg_blank.v -- reuse, don't retype: wrap sseg_hex
module sseg_blank (
    input [3:0] hex,
    input blank,
    output [6:0] seg
);
wire [6:0] core;
sseg_hex u_core (.hex(hex), .seg(core));
// active low: all 1s = every segment dark
assign seg = blank ? 7'b1111111 : core;
endmodule