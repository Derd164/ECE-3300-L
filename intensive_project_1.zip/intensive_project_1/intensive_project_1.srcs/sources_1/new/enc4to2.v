`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 01:33:55 PM
// Design Name: 
// Module Name: enc4to2
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// enc4to2.v -- 4-to-2 priority encoder, highest wins
module enc4to2 (
    input [3:0] r, // r[3] outranks them all
    output reg [1:0] y,
    output reg valid
);
always @(*) begin
    y = 2'd0; valid = 1'b1; // safe values first
    if (r[3]) y = 2'd3;
    else if (r[2]) y = 2'd2;
    else if (r[1]) y = 2'd1;
    else if (r[0]) y = 2'd0;
    else valid = 1'b0; // nobody asked
end
endmodule