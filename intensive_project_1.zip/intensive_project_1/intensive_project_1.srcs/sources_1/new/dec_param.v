`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 03:40:18 PM
// Design Name: 
// Module Name: dec_param
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// dec_param.v -- N-to-2^N decoder: generate compares per row
module dec_param #(
    parameter N = 3
    )(
        input [N-1:0] sel,
        input en,
        output [(1<<N)-1:0] y
    );
        genvar i;
        generate
        for (i = 0; i < (1 << N); i = i + 1) begin : row
        assign y[i] = en & (sel == i);
    end
endgenerate
endmodule