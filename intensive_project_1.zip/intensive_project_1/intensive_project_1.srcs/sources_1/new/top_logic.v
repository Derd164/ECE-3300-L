`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 03:50:45 PM
// Design Name: 
// Module Name: top_logic
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// top_logic.v -- SW nibbles through the whole S1 toolbox
module top_logic (
    input [7:0] SW,
    output [15:0] LED
);
    wire [3:0] a = SW[3:0];
    wire [3:0] b = SW[7:4];
    assign LED[3:0] = a & b;
    assign LED[7:4] = a | b;
    assign LED[11:8] = a ^ b;
    assign LED[12] = (a == b); // eqN idea, 4 bits wide
    assign LED[13] = &SW; // all eight switches up
    assign LED[14] = |SW; // any switch up
    assign LED[15] = ^SW; // odd number of switches up
endmodule