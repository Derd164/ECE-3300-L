`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 12:00:51 PM
// Design Name: 
// Module Name: mux4_struct
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// mux4_struct.v -- 4:1 built from three 2:1s, structural
module mux4_struct (
    input [3:0] d,
    input [1:0] sel,
    output y
);
wire lo, hi; // winners of the two first-round matches
mux2_df m_lo (.a(d[0]), .b(d[1]), .sel(sel[0]), .y(lo));
mux2_df m_hi (.a(d[2]), .b(d[3]), .sel(sel[0]), .y(hi));
mux2_df m_fin (.a(lo), .b(hi), .sel(sel[1]), .y(y));
endmodule
