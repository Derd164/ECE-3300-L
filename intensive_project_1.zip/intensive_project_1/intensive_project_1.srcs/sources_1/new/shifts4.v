`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 02:39:03 PM
// Design Name: 
// Module Name: shifts4
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// shifts4.v -- logical shifts: bits fall off the edge
module shifts4 (
    input [3:0] a,
    input [1:0] s,
    output [3:0] l, // a << s : zeros enter on the right
    output [3:0] r // a >> s : zeros enter on the left
);
assign l = a << s;
assign r = a >> s;
endmodule