`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 12:03:55 PM
// Design Name: 
// Module Name: demux1to4
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// demux1to4.v -- one input, routed to one of four outputs
module demux1to4 (
    input d, en,
    input [1:0] sel,
    output [3:0] y
);
assign y = en ? (d << sel) : 4'b0000;
endmodule