`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 03:34:22 PM
// Design Name: 
// Module Name: eqN
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// eqN.v -- N-bit equality: XNOR the bits, AND the answers
module eqN #(
    parameter N = 8
    )(
        input [N-1:0] a, b,
        output eq
    );
        wire [N-1:0] same;
        genvar i;
        generate
        for (i = 0; i < N; i = i + 1) begin : cmp
        assign same[i] = ~(a[i] ^ b[i]);
    end
endgenerate
assign eq = &same;
endmodule