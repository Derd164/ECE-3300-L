`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 02:13:06 PM
// Design Name: 
// Module Name: cmp4
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// cmp4.v -- 4-bit comparator, default-first vaccine
module cmp4 (
    input [3:0] a, b,
    output reg lt, eq, gt
);
always @(*) begin
    lt = 1'b0; eq = 1'b0; gt = 1'b0; // safe values first
    if (a < b) lt = 1'b1;
    else if (a == b) eq = 1'b1;
    else gt = 1'b1;
end
endmodule