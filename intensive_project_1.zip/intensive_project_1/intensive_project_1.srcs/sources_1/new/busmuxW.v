`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 03:29:38 PM
// Design Name: 
// Module Name: busmuxW
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// busmuxW.v -- W-bit 2:1 mux built from W mux2 slices
module busmuxW #(
    parameter W = 8
    )(
        input [W-1:0] a, b,
        input sel,
        output [W-1:0] y
    );
        genvar i;
        generate
        for (i = 0; i < W; i = i + 1) begin : bit
        mux2_df m (.a(a[i]), .b(b[i]), .sel(sel), .y(y[i]));
    end
endgenerate
endmodule