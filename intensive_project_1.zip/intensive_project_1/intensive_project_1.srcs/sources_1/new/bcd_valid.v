`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 03:03:39 PM
// Design Name: 
// Module Name: bcd_valid
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// bcd_valid.v -- flag a nibble that is not a decimal digit
module bcd_valid (
    input [3:0] d,
    output bad // 1 for A..F
);
assign bad = (d > 4'd9);
endmodule