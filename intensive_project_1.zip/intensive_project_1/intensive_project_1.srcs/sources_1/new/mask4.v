`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/19/2026 03:30:50 PM
// Design Name: 
// Module Name: mask4
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// mask4.v -- set, clear, toggle bits with a mask
module mask4 (
    input [3:0] a, m,
    output [3:0] y_set, // force mask bits to 1
    output [3:0] y_clr, // force mask bits to 0
    output [3:0] y_tgl // flip mask bits
);
assign y_set = a | m;
assign y_clr = a & ~m;
assign y_tgl = a ^ m;
endmodule