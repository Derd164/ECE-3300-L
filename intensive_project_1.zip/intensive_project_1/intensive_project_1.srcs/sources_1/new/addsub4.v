`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 02:05:08 PM
// Design Name: 
// Module Name: addsub4
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// addsub4.v -- adder that subtracts: invert b and carry in 1
module addsub4 (
    input [3:0] a, b,
    input m, // 0 = add, 1 = subtract
    output [3:0] r,
    output cout // in subtract mode: NOT-borrow
);
wire [3:0] bx = b ^ {4{m}}; // m=1 flips every bit
assign {cout, r} = a + bx + m; // ... and adds the +1
endmodule