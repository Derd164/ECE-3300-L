`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 03:25:13 PM
// Design Name: 
// Module Name: gray2binN
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// gray2binN.v -- the XOR chain from E33, written by generate
module gray2binN #(
    parameter N = 8
    )(
        input [N-1:0] g,
        output [N-1:0] b
    );
        assign b[N-1] = g[N-1];
        genvar i;
        generate
        for (i = N-2; i >= 0; i = i - 1) begin : chain
        assign b[i] = b[i+1] ^ g[i];
    end
endgenerate
endmodule