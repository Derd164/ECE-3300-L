`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 12:17:47 PM
// Design Name: 
// Module Name: dec2to4_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// dec2to4_tb.v -- all 8 combos of {en, sel}, printed
module dec2to4_tb;
    reg [1:0] sel;
    reg en;
    wire [3:0] y;
    integer i, errors;
    dec2to4 dut (.sel(sel), .en(en), .y(y));
initial begin
    errors = 0;
    for (i = 0; i < 8; i = i + 1) begin
        {en, sel} = i[2:0];
        #10;
        $display("en=%b sel=%b | y=%b", en, sel, y);
        if (y !== (en ? (4'b0001 << sel) : 4'b0000))
        errors = errors + 1;
    end
    $display("done: %0d errors", errors);
    $finish;
end
endmodule
