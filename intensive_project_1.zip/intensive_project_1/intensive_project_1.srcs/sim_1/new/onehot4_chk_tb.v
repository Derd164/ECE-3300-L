`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 01:42:54 PM
// Design Name: 
// Module Name: onehot4_chk_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// onehot4_chk_tb.v -- sweep 16, plus a meta-check: 4 hits
module onehot4_chk_tb;
    reg [3:0] r;
    wire ok;
    integer i, k, ones, hits, errors;
    onehot4_chk dut (.r(r), .ok(ok));
initial begin
    errors = 0; hits = 0;
    for (i = 0; i < 16; i = i + 1) begin
        r = i[3:0]; #10;
        ones = 0;
        for (k = i; k > 0; k = k >> 1)
        ones = ones + (k & 1);
        if (ok !== (ones == 1)) errors = errors + 1;
        if (ok) hits = hits + 1;
    end
    $display("ok fired %0d times across 16 inputs", hits);
    if (hits != 4) errors = errors + 1; // meta-check
    $display("done: %0d errors", errors);
    $finish;
end
endmodule