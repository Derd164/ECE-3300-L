`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 03:04:53 PM
// Design Name: 
// Module Name: bcd_valid_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// bcd_valid_tb.v -- the 9/10 fence post, then all 16
module bcd_valid_tb;
    reg [3:0] d;
    wire bad;
    integer i, errors;
    bcd_valid dut (.d(d), .bad(bad));
initial begin
    errors = 0;
    // corners: both sides of the only fence
    d = 4'd9; #10;
    $display("corner d=9 : bad=%b (last legal digit)", bad);
    if (bad !== 1'b0) errors = errors + 1;
    d = 4'd10; #10;
    $display("corner d=10: bad=%b (first illegal)", bad);
    if (bad !== 1'b1) errors = errors + 1;
    // the sweep
    for (i = 0; i < 16; i = i + 1) begin
        d = i[3:0]; #10;
        if (bad !== (i > 9)) errors = errors + 1;
    end
    $display("swept all 16 nibbles");
    $display("done: %0d errors", errors);
    $finish;
end
endmodule