`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 11:51:16 AM
// Design Name: 
// Module Name: mux2_beh_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// mux2_beh_tb.v -- two dialects, one chip: cross-checked
module mux2_beh_tb;
    reg a, b, sel;
    wire y_df, y_beh;
    integer i, errors;
    mux2_df u_df (.a(a), .b(b), .sel(sel), .y(y_df));
    mux2_beh u_beh (.a(a), .b(b), .sel(sel), .y(y_beh));
initial begin
    errors = 0;
    for (i = 0; i < 8; i = i + 1) begin
        {sel, b, a} = i[2:0];
        #10;
        if (y_df !== (sel ? b : a)) errors = errors + 1;
        if (y_beh !== y_df) begin
            errors = errors + 1;
            $display("FAIL: dialects disagree at %b", i[2:0]);
        end
    end
    $display("8 rows: if/else and ?: agree on every one");
    $display("done: %0d errors", errors);
    $finish;
end
endmodule
