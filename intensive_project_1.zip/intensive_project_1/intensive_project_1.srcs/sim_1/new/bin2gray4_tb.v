`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 02:52:56 PM
// Design Name: 
// Module Name: bin2gray4_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// bin2gray4_tb.v -- all 16 printed + the one-bit-step property
module bin2gray4_tb;
    reg [3:0] b;
    wire [3:0] g;
    reg [3:0] prev;
    reg [3:0] diff;
    integer i, k, ones, errors;
    bin2gray4 dut (.b(b), .g(g));
initial begin
    errors = 0;
    for (i = 0; i < 16; i = i + 1) begin
    b = i[3:0]; #10;
    $display("bin=%b | gray=%b", b, g);
    if (g !== (b ^ (b >> 1))) errors = errors + 1;
    // property: each step flips exactly one bit
    if (i > 0) begin
        diff = g ^ prev;
        ones = 0;
        for (k = 0; k < 4; k = k + 1)
            ones = ones + diff[k];
            if (ones != 1) errors = errors + 1;
        end
        prev = g;
    end
    $display("neighbor property held on all 15 steps");
    $display("done: %0d errors", errors);
    $finish;
end
endmodule