`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 11:45:46 AM
// Design Name: 
// Module Name: mux2_df_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// mux2_df_tb.v -- eight rows read like a truth table
module mux2_df_tb;
    reg a, b, sel;
    wire y;
    integer i, errors;
    mux2_df dut (.a(a), .b(b), .sel(sel), .y(y));
initial begin
    errors = 0;
    for (i = 0; i < 8; i = i + 1) begin
        {sel, b, a} = i[2:0];
        #10;
        $display("sel=%b b=%b a=%b | y=%b", sel, b, a, y);
        if (y !== (sel ? b : a)) errors = errors + 1;
    end
    $display("done: %0d errors", errors);
    $finish;
end
endmodule
