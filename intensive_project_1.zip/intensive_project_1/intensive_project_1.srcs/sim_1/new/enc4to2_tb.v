`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 01:35:28 PM
// Design Name: 
// Module Name: enc4to2_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// enc4to2_tb.v -- corners, then all 16 vs a golden priority
module enc4to2_tb;
    reg [3:0] r;
    wire [1:0] y;
    wire valid;
    integer i, exp, errors;
    enc4to2 dut (.r(r), .y(y), .valid(valid));
initial begin
    errors = 0;
    // corner: silence -- nobody requests
    r = 4'b0000; #10;
    $display("corner r=0000: y=%b valid=%b", y, valid);
    if ({valid, y} !== 3'b000) errors = errors + 1;
    // corner: everybody requests -- highest must win
    r = 4'b1111; #10;
    $display("corner r=1111: y=%b valid=%b", y, valid);
    if ({valid, y} !== 3'b111) errors = errors + 1;
    // corner: a lone low request survives
    r = 4'b0001; #10;
    $display("corner r=0001: y=%b valid=%b", y, valid);
    if ({valid, y} !== 3'b100) errors = errors + 1;
    // the sweep: golden priority computed independently
    for (i = 0; i < 16; i = i + 1) begin
        r = i[3:0]; #10;
        if (i >= 8) exp = 3;
        else if (i >= 4) exp = 2;
        else if (i >= 2) exp = 1;
        else exp = 0;
        if (valid !== (i != 0)) errors = errors + 1;
        if ((i != 0) && (y !== exp[1:0])) errors = errors + 1;
    end
    $display("swept all 16 request patterns");
    $display("done: %0d errors", errors);
    $finish;
end
endmodule
