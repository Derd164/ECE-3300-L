`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 01:54:50 PM
// Design Name: 
// Module Name: full_adder_df_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// full_adder_df_tb.v -- eight rows: three bits counted
module full_adder_df_tb;
    reg a, b, cin;
    wire s, co;
    integer i, errors;
    full_adder_df dut (.a(a), .b(b), .cin(cin), .s(s), .co(co));
initial begin
    errors = 0;
    for (i = 0; i < 8; i = i + 1) begin
        {cin, b, a} = i[2:0];
        #10;
        $display("cin=%b b=%b a=%b | co=%b s=%b",
        cin, b, a, co, s);
        if ({co, s} !== a + b + cin) errors = errors + 1;
    end
    $display("done: %0d errors", errors);
    $finish;
end
endmodule