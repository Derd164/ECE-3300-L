`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 01:46:51 PM
// Design Name: 
// Module Name: addr_dec_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// addr_dec_tb.v -- fence-post corners first, then all 16
module addr_dec_tb;
    reg [3:0] a;
    wire sel;
    integer i, errors;
    addr_dec dut (.a(a), .sel(sel));
initial begin
    errors = 0;
    // corners: both fence posts, both sides of each
    a = 4'd3; #10; if (sel !== 1'b0) errors = errors + 1;
    $display("corner a=3 (below): sel=%b", sel);
    a = 4'd4; #10; if (sel !== 1'b1) errors = errors + 1;
    $display("corner a=4 (first): sel=%b", sel);
    a = 4'd11; #10; if (sel !== 1'b1) errors = errors + 1;
    $display("corner a=11 (last) : sel=%b", sel);
    a = 4'd12; #10; if (sel !== 1'b0) errors = errors + 1;
    $display("corner a=12 (above): sel=%b", sel);
    // the sweep
    for (i = 0; i < 16; i = i + 1) begin
        a = i[3:0]; #10;
        if (sel !== ((i >= 4) && (i <= 11)))
        errors = errors + 1;
    end
    $display("swept all 16 addresses");
    $display("done: %0d errors", errors);
    $finish;
end
endmodule
