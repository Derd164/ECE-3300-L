`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 02:01:08 PM
// Design Name: 
// Module Name: add4_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// add4_tb.v -- carry corners first, then all 256 in silence
module add4_tb;
    reg [3:0] a, b;
    wire [3:0] sum;
    wire cout;
    integer i, j, errors;
    add4 dut (.a(a), .b(b), .sum(sum), .cout(cout));
initial begin
    errors = 0;
    // corner: zero plus zero
    a = 4'h0; b = 4'h0; #10;
    if ({cout, sum} !== 5'h00) errors = errors + 1;
    $display("corner 0+0 : cout=%b sum=%h", cout, sum);
    // corner: the biggest sum the port can carry
    a = 4'hF; b = 4'hF; #10;
    if ({cout, sum} !== 5'h1E) errors = errors + 1;
    $display("corner F+F : cout=%b sum=%h (30)", cout, sum);
    // corner: wrap by exactly one
    a = 4'hF; b = 4'h1; #10;
    if ({cout, sum} !== 5'h10) errors = errors + 1;
    $display("corner F+1 : cout=%b sum=%h (16)", cout, sum);
    // corner: carry out, sum all zero
    a = 4'h8; b = 4'h8; #10;
    if ({cout, sum} !== 5'h10) errors = errors + 1;
    $display("corner 8+8 : cout=%b sum=%h", cout, sum);
    // the sweep: every pair, golden at 5 bits
    for (i = 0; i < 16; i = i + 1)
    for (j = 0; j < 16; j = j + 1) begin
        a = i[3:0]; b = j[3:0];
        #10;
        if ({cout, sum} !== i[4:0] + j[4:0])
        errors = errors + 1;
    end
    $display("swept all 256 sums");
    $display("done: %0d errors", errors);
    $finish;
end
endmodule