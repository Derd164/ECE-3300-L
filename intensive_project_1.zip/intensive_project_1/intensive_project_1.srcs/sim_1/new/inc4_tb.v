`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 02:09:22 PM
// Design Name: 
// Module Name: inc4_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// inc4_tb.v -- the wrap corner, then all 16
module inc4_tb;
    reg [3:0] a;
    wire [3:0] y;
    wire wrap;
    integer i, errors;
    inc4 dut (.a(a), .y(y), .wrap(wrap));
initial begin
    errors = 0;
    // corner: the odometer rolls over
    a = 4'hF; #10;
    $display("corner F+1: wrap=%b y=%h", wrap, y);
    if ({wrap, y} !== 5'h10) errors = errors + 1;
    // the sweep
    for (i = 0; i < 16; i = i + 1) begin
        a = i[3:0]; #10;
        if ({wrap, y} !== i[4:0] + 5'd1) errors = errors + 1;
    end
    $display("swept all 16 values");
    $display("done: %0d errors", errors);
    $finish;
end
endmodule