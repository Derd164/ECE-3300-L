`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 03:41:29 PM
// Design Name: 
// Module Name: dec_param_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// dec_param_tb.v -- N=3 vs the hand-built dec3to8: twins
module dec_param_tb;
    reg [2:0] sel;
    reg en;
    wire [7:0] y_p, y_h;
    integer i, errors;
    dec_param #(.N(3)) u_p (.sel(sel), .en(en), .y(y_p));
    dec3to8 u_h (.sel(sel), .en(en), .y(y_h));
initial begin
    errors = 0;
    for (i = 0; i < 16; i = i + 1) begin
        {en, sel} = i[3:0]; #10;
        if (y_p !== (en ? (8'b1 << sel) : 8'b0))
        errors = errors + 1;
        if (y_p !== y_h) begin
            errors = errors + 1;
            $display("FAIL: param and hand-built split");
        end
    end
    $display("16 rows: generated == hand-built, every one");
    $display("done: %0d errors", errors);
    $finish;
end
endmodule