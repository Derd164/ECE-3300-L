`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 03:10:28 PM
// Design Name: 
// Module Name: sseg_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// sseg_tb.v -- draws every glyph in ASCII, then three checks
module sseg_tb;
    reg [3:0] hex;
    wire [6:0] seg;
    reg [6:0] pat [0:15]; // remember all 16 patterns
    integer i, j, errors;
    sseg_hex dut (.hex(hex), .seg(seg));
initial begin
    errors = 0;
    for (i = 0; i < 16; i = i + 1) begin
        hex = i[3:0];
        #10;
        pat[i] = seg;
        $display("hex=%h seg=%b", i[3:0], seg);
        $display(" %s", seg[0] ? " " : " _ ");
        $display(" %s%s%s", seg[5] ? " " : "|",
        seg[6] ? " " : "_",
        seg[1] ? " " : "|");
        $display(" %s%s%s", seg[4] ? " " : "|",
        seg[3] ? " " : "_",
        seg[2] ? " " : "|");
        // check 1: every bit defined -- no x, no z
        if (^seg === 1'bx) begin
            errors = errors + 1;
            $display("FAIL: undefined bit in glyph %h", i[3:0]);
        end
    end
    // check 2: all 16 glyphs must be distinct
    for (i = 0; i < 16; i = i + 1)
    for (j = i + 1; j < 16; j = j + 1)
    if (pat[i] === pat[j]) begin
        errors = errors + 1;
        $display("FAIL: %h and %h identical", i[3:0], j[3:0]);
    end
    // check 3: garbage in, defined glyph out (rule 4!)
    hex = 4'bxxxx;
    #10;
    if (seg !== 7'b0001110) begin
        errors = errors + 1;
        $display("FAIL: x input missed the default");
    end
    $display("garbage test: hex=xxxx -> seg=%b", seg);
    $display("done: %0d errors", errors);
    $finish;
end
endmodule