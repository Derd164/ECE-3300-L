`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 03:59:26 PM
// Design Name: 
// Module Name: top_addsub_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// top_addsub_tb.v -- the three settings promised on the slide
module top_addsub_tb;
    reg [15:0] SW;
    wire [15:0] LED;
    integer errors;
    top_addsub dut (.SW(SW), .LED(LED));
initial begin
    errors = 0;
    // add mode: 3 + 5 = 8
    SW = 16'h0053; #10;
    $display("SW=0053 add 3+5: LED[4:0]=%b zero=%b",
    LED[4:0], LED[13]);
    if (LED[4:0] !== 5'b01000) errors = errors + 1;
    if (LED[13] !== 1'b0) errors = errors + 1;
    // sub mode: 5 - 5 = 0, no borrow, zero flag up
    SW = 16'h8055; #10;
    $display("SW=8055 sub 5-5: LED[4:0]=%b zero=%b",
    LED[4:0], LED[13]);
    if (LED[4:0] !== 5'b10000) errors = errors + 1;
    if (LED[13] !== 1'b1) errors = errors + 1;
    // sub mode: 2 - 7 wraps, borrow shows as cout=0
    SW = 16'h8072; #10;
    $display("SW=8072 sub 2-7: LED[4:0]=%b (borrow)",
    LED[4:0]);
    if (LED[4:0] !== 5'b01011) errors = errors + 1;
    $display("done: %0d errors", errors);
    $finish;
end
endmodule