`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 03:26:31 PM
// Design Name: 
// Module Name: gray2binN_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// gray2binN_tb.v -- round trip at N=8: all 256 values
module gray2binN_tb;
    reg [7:0] g;
    wire [7:0] b;
    integer i, errors;
    gray2binN #(.N(8)) dut (.g(g), .b(b));
initial begin
    errors = 0;
    // corners: both extremes of the code
    g = 8'h00; #10;
    if (b !== 8'h00) errors = errors + 1;
    g = 8'h80; #10; // gray 1000_0000 = binary 255
    $display("corner g=80: b=%h (all-ones decoded)", b);
    if (b !== 8'hFF) errors = errors + 1;
    // the round trip: encode i, decode, expect i back
    for (i = 0; i < 256; i = i + 1) begin
        g = i[7:0] ^ (i[7:0] >> 1);
        #10;
        if (b !== i[7:0]) errors = errors + 1;
    end
    $display("round trip closed on all 256 values");
    $display("done: %0d errors", errors);
    $finish;
end
endmodule