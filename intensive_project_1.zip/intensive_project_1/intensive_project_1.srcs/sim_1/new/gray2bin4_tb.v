`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 02:59:10 PM
// Design Name: 
// Module Name: gray2bin4_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// gray2bin4_tb.v -- the round trip: encode, decode, compare
module gray2bin4_tb;
    reg [3:0] g;
    wire [3:0] b;
    integer i, errors;
    gray2bin4 dut (.g(g), .b(b));
initial begin
    errors = 0;
    for (i = 0; i < 16; i = i + 1) begin
        g = i[3:0] ^ (i[3:0] >> 1); // encode i on the fly
        #10;
        $display("gray=%b | bin=%b", g, b);
        if (b !== i[3:0]) errors = errors + 1;
    end
    $display("round trip closed on all 16 values");
    $display("done: %0d errors", errors);
    $finish;
end
endmodule