`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 02:34:51 PM
// Design Name: 
// Module Name: swap_nib8_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// swap_nib8_tb.v -- corners incl. palindromes, then 256
module swap_nib8_tb;
    reg [7:0] a;
    wire [7:0] y;
    integer i, errors;
    swap_nib8 dut (.a(a), .y(y));
initial begin
    errors = 0;
    // corner: the classic
    a = 8'hA5; #10;
    $display("corner A5 -> %h", y);
    if (y !== 8'h5A) errors = errors + 1;
    // corner: palindromes must survive unchanged
    a = 8'h00; #10; if (y !== 8'h00) errors = errors + 1;
    a = 8'hFF; #10; if (y !== 8'hFF) errors = errors + 1;
    a = 8'h33; #10; if (y !== 8'h33) errors = errors + 1;
    $display("palindromes 00 FF 33: unchanged");
    // the sweep: swap twice = original (round trip golden)
    for (i = 0; i < 256; i = i + 1) begin
        a = i[7:0]; #10;
        if (y !== {a[3:0], a[7:4]}) errors = errors + 1;
    end
    $display("swept all 256 bytes");
    $display("done: %0d errors", errors);
    $finish;
end
endmodule