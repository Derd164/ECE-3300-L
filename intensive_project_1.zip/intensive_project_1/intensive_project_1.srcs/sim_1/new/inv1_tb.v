`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/19/2026 02:35:21 PM
// Design Name: 
// Module Name: inv1_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// inv1_tb.v -- two rows: the whole truth table
module inv1_tb;
    reg a;
    wire y;
    integer i, errors;
    inv1 dut (.a(a), .y(y));
initial begin
    errors = 0;
    for (i = 0; i < 2; i = i + 1) begin
        a = i[0];
        #10;
        $display("a=%b | y=%b", a, y);
        if (y !== ~a) errors = errors + 1;
    end
    $display("done: %0d errors", errors);
    $finish;
end
endmodule
