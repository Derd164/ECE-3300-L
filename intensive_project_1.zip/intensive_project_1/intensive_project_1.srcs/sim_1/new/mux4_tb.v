`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 11:56:56 AM
// Design Name: 
// Module Name: mux4_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// mux4_tb.v -- corners: sel walk on a one-hot, then all 64
module mux4_tb;
    reg [3:0] d;
    reg [1:0] sel;
    wire y;
    integer i, errors;
    mux4 dut (.d(d), .sel(sel), .y(y));
initial begin
    errors = 0;
    // corners: one-hot data, walk sel -- y must trace the 1
    d = 4'b0100;
    for (i = 0; i < 4; i = i + 1) begin
        sel = i[1:0]; #10;
        $display("d=%b sel=%b | y=%b", d, sel, y);
        if (y !== (i == 2)) errors = errors + 1;
     end
        // the sweep: every {sel, d} combination
     for (i = 0; i < 64; i = i + 1) begin
        {sel, d} = i[5:0];
        #10;
        if (y !== d[sel]) errors = errors + 1;
    end
    $display("swept all 64 combinations of sel and d");
    $display("done: %0d errors", errors);
    $finish;
end
endmodule
