`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 12:04:50 PM
// Design Name: 
// Module Name: demux1to4_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// demux1to4_tb.v -- all 16 combos of {en, sel, d}
module demux1to4_tb;
    reg d, en;
    reg [1:0] sel;
    wire [3:0] y;
    integer i, errors;
    demux1to4 dut (.d(d), .en(en), .sel(sel), .y(y));
initial begin
    errors = 0;
    for (i = 0; i < 16; i = i + 1) begin
        {en, sel, d} = i[3:0];
        #10;
        $display("en=%b sel=%b d=%b | y=%b", en, sel, d, y);
        if (y !== (en ? (d << sel) : 4'b0000))
        errors = errors + 1;
    end
    $display("done: %0d errors", errors);
    $finish;
end
endmodule