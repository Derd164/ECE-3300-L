`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/19/2026 03:18:45 PM
// Design Name: 
// Module Name: nand2_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// nand2_tb.v -- four rows: AND flipped upside down
module nand2_tb;
    reg a, b;
    wire y;
    integer i, errors;
    nand2 dut (.a(a), .b(b), .y(y));
initial begin
    errors = 0;
    for (i = 0; i < 4; i = i + 1) begin
        {b, a} = i[1:0];
        #10;
        $display("b=%b a=%b | y=%b", b, a, y);
        if (y !== ~(a & b)) errors = errors + 1;
    end
    $display("done: %0d errors", errors);
    $finish;
end
endmodule
