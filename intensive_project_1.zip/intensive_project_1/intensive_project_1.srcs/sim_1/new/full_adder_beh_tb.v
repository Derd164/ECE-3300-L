`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 01:57:56 PM
// Design Name: 
// Module Name: full_adder_beh_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// full_adder_beh_tb.v -- equations vs arithmetic, cross-checked
module full_adder_beh_tb;
    reg a, b, cin;
    wire s1, c1, s2, c2;
    integer i, errors;
    full_adder_df u1 (.a(a), .b(b), .cin(cin), .s(s1), .co(c1));
    full_adder_beh u2 (.a(a), .b(b), .cin(cin), .s(s2), .co(c2));
initial begin
    errors = 0;
    for (i = 0; i < 8; i = i + 1) begin
        {cin, b, a} = i[2:0];
        #10;
        if ({c1, s1} !== a + b + cin) errors = errors + 1;
        if ({c2, s2} !== {c1, s1}) begin
            errors = errors + 1;
            $display("FAIL: styles split at %b", i[2:0]);
        end
    end
    $display("gate equations == one-line add, all 8 rows");
    $display("done: %0d errors", errors);
    $finish;
end
endmodule