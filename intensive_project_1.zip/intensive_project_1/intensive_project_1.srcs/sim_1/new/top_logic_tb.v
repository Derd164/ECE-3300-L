`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 03:52:47 PM
// Design Name: 
// Module Name: top_logic_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// top_logic_tb.v -- corners + full 256 sweep of the panel
module top_logic_tb;
    reg [7:0] SW;
    wire [15:0] LED;
    integer i, k, g, errors;
    top_logic dut (.SW(SW), .LED(LED));
    task check;
    begin
        if (LED[3:0] !== (SW[3:0] & SW[7:4]))
        errors = errors + 1;
        if (LED[7:4] !== (SW[3:0] | SW[7:4]))
        errors = errors + 1;
        if (LED[11:8] !== (SW[3:0] ^ SW[7:4]))
        errors = errors + 1;
        if (LED[12] !== (SW[3:0] == SW[7:4]))
        errors = errors + 1;
        if (LED[13] !== (&SW)) errors = errors + 1;
        if (LED[14] !== (|SW)) errors = errors + 1;
        if (LED[15] !== (^SW)) errors = errors + 1;
    end
    endtask
initial begin
    errors = 0;
    SW = 8'h00; #10; check;
    $display("corner SW=00: LED=%b", LED);
    SW = 8'hFF; #10; check;
    $display("corner SW=FF: LED=%b", LED);
    SW = 8'h99; #10; check; // equal nibbles
    $display("corner SW=99: LED12=%b (nibbles equal)",
    LED[12]);
    for (i = 0; i < 256; i = i + 1) begin
        SW = i[7:0]; #10; check;
    end
    $display("swept all 256 switch settings");
    $display("done: %0d errors", errors);
    $finish;
end
endmodule