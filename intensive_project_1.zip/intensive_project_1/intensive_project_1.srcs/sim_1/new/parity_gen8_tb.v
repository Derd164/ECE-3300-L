`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 02:20:44 PM
// Design Name: 
// Module Name: parity_gen8_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// parity_gen8_tb.v -- corners + one-hot walk + full 256 sweep
module parity_gen8_tb;
    reg [7:0] d;
    wire p;
    integer i, k, g, errors;
    parity_gen8 dut (.d(d), .p(p));
initial begin
    errors = 0;
    // corners: both extremes
    d = 8'h00; #10;
    $display("corner 00: p=%b (zero ones = even)", p);
    if (p !== 1'b0) errors = errors + 1;
    d = 8'hFF; #10;
    $display("corner FF: p=%b (eight ones = even)", p);
    if (p !== 1'b0) errors = errors + 1;
    // corner walk: a single 1 in every seat -> p=1
    for (i = 0; i < 8; i = i + 1) begin
        d = 8'h01 << i; #10;
        if (p !== 1'b1) errors = errors + 1;
        end
        $display("one-hot walk: p=1 at all 8 stops");
        // the sweep: golden parity counted bit by bit
        for (i = 0; i < 256; i = i + 1) begin
        d = i[7:0]; #10;
        g = 0;
        for (k = i; k > 0; k = k >> 1) g = g ^ (k & 1);
        if (p !== g[0]) errors = errors + 1;
    end
    $display("swept all 256 words");
    $display("done: %0d errors", errors);
    $finish;
end
endmodule