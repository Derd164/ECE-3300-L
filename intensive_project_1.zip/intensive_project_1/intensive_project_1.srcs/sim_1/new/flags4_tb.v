`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 02:30:02 PM
// Design Name: 
// Module Name: flags4_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// flags4_tb.v -- all 16, flags printed as a story
module flags4_tb;
    reg [3:0] a;
    wire zero, neg;
    integer i, errors;
    flags4 dut (.a(a), .zero(zero), .neg(neg));
initial begin
    errors = 0;
    for (i = 0; i < 16; i = i + 1) begin
        a = i[3:0]; #10;
        $display("a=%b | zero=%b neg=%b", a, zero, neg);
        if (zero !== (i == 0)) errors = errors + 1;
        if (neg !== a[3]) errors = errors + 1;
    end
    $display("done: %0d errors", errors);
    $finish;
end
endmodule