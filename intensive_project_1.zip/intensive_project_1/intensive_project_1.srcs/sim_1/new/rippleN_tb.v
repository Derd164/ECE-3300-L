`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 03:23:04 PM
// Design Name: 
// Module Name: rippleN_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// rippleN_tb.v -- one source, two widths: N=4 and N=8
module rippleN_tb;
    reg [3:0] a4, b4;
    reg [7:0] a8, b8;
    reg cin;
    wire [3:0] s4;
    wire [7:0] s8;
    wire c4, c8;
    integer i, j, errors;
    rippleN #(.N(4)) u4 (.a(a4), .b(b4), .cin(cin),
    .sum(s4), .cout(c4));
    rippleN #(.N(8)) u8 (.a(a8), .b(b8), .cin(cin),
    .sum(s8), .cout(c8));
initial begin
    errors = 0;
    // corners on N=8: extremes and the longest carry ride
    a8 = 8'h00; b8 = 8'h00; cin = 0; #10;
    if ({c8, s8} !== 9'h000) errors = errors + 1;
    a8 = 8'hFF; b8 = 8'hFF; cin = 1; #10;
    $display("corner FF+FF+1: cout=%b sum=%h", c8, s8);
    if ({c8, s8} !== 9'h1FF) errors = errors + 1;
    a8 = 8'hFF; b8 = 8'h01; cin = 0; #10;
    $display("corner FF+01 : carry rides all 8 slices");
    if ({c8, s8} !== 9'h100) errors = errors + 1;
    // N=4 sweep: all 512 with carry-in
    for (i = 0; i < 512; i = i + 1) begin
        {cin, b4, a4} = i[8:0]; #10;
        if ({c4, s4} !== a4 + b4 + cin) errors = errors + 1;
    end
    $display("N=4: swept all 512");
    // N=8 sweep: all 65536 pairs, cin=0, in silence
    cin = 0;
    for (i = 0; i < 256; i = i + 1)
    for (j = 0; j < 256; j = j + 1) begin
        a8 = i[7:0]; b8 = j[7:0]; #10;
        if ({c8, s8} !== i[8:0] + j[8:0])
        errors = errors + 1;
    end
    $display("N=8: swept all 65536 pairs");
    $display("done: %0d errors", errors);
    $finish;
end
endmodule