`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 12:01:52 PM
// Design Name: 
// Module Name: mux4_struct_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// mux4_struct_tb.v -- tournament vs table: 64 agreements
module mux4_struct_tb;
    reg [3:0] d;
    reg [1:0] sel;
    wire y_s, y_b;
    integer i, errors;
    mux4_struct u_s (.d(d), .sel(sel), .y(y_s));
    mux4 u_b (.d(d), .sel(sel), .y(y_b));
initial begin
    errors = 0;
    for (i = 0; i < 64; i = i + 1) begin
        {sel, d} = i[5:0];
        #10;
        if (y_s !== d[sel]) begin
            errors = errors + 1;
            $display("FAIL struct: d=%b sel=%b y=%b", d, sel, y_s);
        end
        if (y_s !== y_b) errors = errors + 1;
    end
    $display("tournament == table on all 64 inputs");
    $display("done: %0d errors", errors);
    $finish;
end
endmodule
