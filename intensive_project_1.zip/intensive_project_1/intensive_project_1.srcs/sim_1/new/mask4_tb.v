`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/19/2026 03:33:01 PM
// Design Name: 
// Module Name: mask4_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// mask4_tb.v -- corners: the two extreme masks, then 256 pairs
module mask4_tb;
    reg [3:0] a, m;
    wire [3:0] y_set, y_clr, y_tgl;
    integer i, j, errors;
    mask4 dut (.a(a), .m(m), .y_set(y_set),
    .y_clr(y_clr), .y_tgl(y_tgl));
    task check;
    begin
        if (y_set !== (a | m)) errors = errors + 1;
        if (y_clr !== (a & ~m)) errors = errors + 1;
        if (y_tgl !== (a ^ m)) errors = errors + 1;
    end
    endtask
initial begin
    errors = 0;
    // corner: mask 0000 -- every op must leave a untouched
    a = 4'b1001; m = 4'b0000; #10; check;
    $display("m=0000: set=%b clr=%b tgl=%b (a passes)",
    y_set, y_clr, y_tgl);
    // corner: mask 1111 -- set->1111, clr->0000, tgl->~a
    a = 4'b1001; m = 4'b1111; #10; check;
    $display("m=1111: set=%b clr=%b tgl=%b", y_set, y_clr, y_tgl);
    // the sweep
    for (i = 0; i < 16; i = i + 1)
    for (j = 0; j < 16; j = j + 1) begin
        a = i[3:0]; m = j[3:0];
        #10; check;
    end
    $display("swept all 256 pairs, 3 ops each");
    $display("done: %0d errors", errors);
    $finish;
end
endmodule
