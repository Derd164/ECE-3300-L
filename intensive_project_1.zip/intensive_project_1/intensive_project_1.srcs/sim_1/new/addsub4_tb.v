`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 02:05:49 PM
// Design Name: 
// Module Name: addsub4_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// addsub4_tb.v -- mode corners, then all 512 combinations
module addsub4_tb;
    reg [3:0] a, b;
    reg m;
    wire [3:0] r;
    wire cout;
    integer i, j, k, exp, errors;
    addsub4 dut (.a(a), .b(b), .m(m), .r(r), .cout(cout));
initial begin
    errors = 0;
    // corner: a - a = 0, with cout=1 saying "no borrow"
    a = 4'h9; b = 4'h9; m = 1; #10;
    $display("corner 9-9: cout=%b r=%h", cout, r);
    if ({cout, r} !== 5'h10) errors = errors + 1;
    // corner: 0 - 1 wraps to F, cout=0 flags the borrow
    a = 4'h0; b = 4'h1; m = 1; #10;
    $display("corner 0-1: cout=%b r=%h (borrow!)", cout, r);
    if ({cout, r} !== 5'h0F) errors = errors + 1;
    // corner: m=0 must be a plain adder
    a = 4'hF; b = 4'h1; m = 0; #10;
    $display("corner F+1: cout=%b r=%h", cout, r);
    if ({cout, r} !== 5'h10) errors = errors + 1;
    // the sweep: both modes, every pair
    for (k = 0; k < 2; k = k + 1)
    for (i = 0; i < 16; i = i + 1)
    for (j = 0; j < 16; j = j + 1) begin
        a = i[3:0]; b = j[3:0]; m = k[0];
        #10;
        if (k) exp = i + ((~j) & 15) + 1;
        else exp = i + j;
        if ({cout, r} !== exp[4:0])
        errors = errors + 1;
    end
    $display("swept all 512: both modes, every pair");
    $display("done: %0d errors", errors);
    $finish;
end
endmodule