`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 03:35:31 PM
// Design Name: 
// Module Name: eqN_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// eqN_tb.v -- diagonal + off-by-one corners, then 65536
module eqN_tb;
    reg [7:0] a, b;
    wire eq;
    integer i, j, errors;
    eqN #(.N(8)) dut (.a(a), .b(b), .eq(eq));
initial begin
    errors = 0;
    // corner walk: the diagonal -- every value equals itself
    for (i = 0; i < 256; i = i + 1) begin
        a = i[7:0]; b = i[7:0]; #10;
        if (eq !== 1'b1) errors = errors + 1;
    end
    $display("diagonal: eq=1 on all 256 self-pairs");
    // corner walk: off-by-one-bit -- the hardest near-miss
    a = 8'h5A;
    for (i = 0; i < 8; i = i + 1) begin
        b = 8'h5A ^ (8'h01 << i); #10;
        if (eq !== 1'b0) errors = errors + 1;
    end
    $display("off-by-one-bit: eq=0 at all 8 positions");
    // the sweep: every pair
    for (i = 0; i < 256; i = i + 1)
    for (j = 0; j < 256; j = j + 1) begin
        a = i[7:0]; b = j[7:0]; #10;
        if (eq !== (i == j)) errors = errors + 1;
    end
    $display("swept all 65536 pairs");
    $display("done: %0d errors", errors);
    $finish;
end
endmodule