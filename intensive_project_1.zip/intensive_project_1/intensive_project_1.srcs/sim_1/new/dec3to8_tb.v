`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 01:30:54 PM
// Design Name: 
// Module Name: dec3to8_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// dec3to8_tb.v -- corners named, then all 16 swept
module dec3to8_tb;
    reg [2:0] sel;
    reg en;
    wire [7:0] y;
    integer i, errors;
    dec3to8 dut (.sel(sel), .en(en), .y(y));
initial begin
    errors = 0;
    // corner: disabled -- sel must be powerless
    en = 0; sel = 3'd5; #10;
    $display("corner en=0 sel=5: y=%b", y);
    if (y !== 8'h00) errors = errors + 1;
    // corners: first and last row of the table
    en = 1; sel = 3'd0; #10;
    $display("corner en=1 sel=0: y=%b", y);
    if (y !== 8'h01) errors = errors + 1;
    sel = 3'd7; #10;
    $display("corner en=1 sel=7: y=%b", y);
    if (y !== 8'h80) errors = errors + 1;
    // the sweep: all 16 {en, sel}, golden = shifted 1
    for (i = 0; i < 16; i = i + 1) begin
        {en, sel} = i[3:0];
        #10;
        if (y !== (en ? (8'b1 << sel) : 8'b0))
        errors = errors + 1;
    end
    $display("swept all 16 combinations");
    $display("done: %0d errors", errors);
    $finish;
end
endmodule
