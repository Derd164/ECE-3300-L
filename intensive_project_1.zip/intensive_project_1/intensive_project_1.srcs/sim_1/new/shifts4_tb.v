`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 02:39:52 PM
// Design Name: 
// Module Name: shifts4_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// shifts4_tb.v -- falling-off-the-edge corners, then all 64
module shifts4_tb;
    reg [3:0] a;
    reg [1:0] s;
    wire [3:0] l, r;
    integer i, errors;
    shifts4 dut (.a(a), .s(s), .l(l), .r(r));
initial begin
    errors = 0;
    // corner: s=0 is the identity
    a = 4'b1011; s = 2'd0; #10;
    $display("corner 1011<<0: l=%b r=%b (identity)", l, r);
    if ({l, r} !== {a, a}) errors = errors + 1;
    // corner: the MSB falls off on a left shift
    a = 4'b1000; s = 2'd1; #10;
    $display("corner 1000<<1: l=%b (the 1 is gone)", l);
    if (l !== 4'b0000) errors = errors + 1;
    // corner: max shift leaves one survivor
    a = 4'b1111; s = 2'd3; #10;
    $display("corner 1111 s=3: l=%b r=%b", l, r);
    if ({l, r} !== {4'b1000, 4'b0001}) errors = errors + 1;
    // the sweep: golden shifts masked to 4 bits
    for (i = 0; i < 64; i = i + 1) begin
        {s, a} = i[5:0]; #10;
        if (l !== ((a << s) & 4'hF)) errors = errors + 1;
        if (r !== (a >> s)) errors = errors + 1;
    end
    $display("swept all 64 combinations");
    $display("done: %0d errors", errors);
    $finish;
end
endmodule