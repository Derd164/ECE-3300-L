`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 02:14:19 PM
// Design Name: 
// Module Name: cmp4_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// cmp4_tb.v -- corners, all 256 verdicts, one-hot property
module cmp4_tb;
    reg [3:0] a, b;
    wire lt, eq, gt;
    integer i, j, errors;
    cmp4 dut (.a(a), .b(b), .lt(lt), .eq(eq), .gt(gt));
initial begin
    errors = 0;
    // corners: the extremes, both orders, and a tie
    a = 4'h0; b = 4'hF; #10;
    if ({lt, eq, gt} !== 3'b100) errors = errors + 1;
    $display("corner 0 vs F: lt=%b eq=%b gt=%b", lt, eq, gt);
    a = 4'hF; b = 4'h0; #10;
    if ({lt, eq, gt} !== 3'b001) errors = errors + 1;
    $display("corner F vs 0: lt=%b eq=%b gt=%b", lt, eq, gt);
    a = 4'h7; b = 4'h7; #10;
    if ({lt, eq, gt} !== 3'b010) errors = errors + 1;
    $display("corner 7 vs 7: lt=%b eq=%b gt=%b", lt, eq, gt);
    // the sweep + the one-hot property on every row
    for (i = 0; i < 16; i = i + 1)
    for (j = 0; j < 16; j = j + 1) begin
        a = i[3:0]; b = j[3:0];
        #10;
        if ({lt, eq, gt} !== {i < j, i == j, i > j})
        errors = errors + 1;
        if (lt + eq + gt !== 2'd1) errors = errors + 1;
    end
    $display("256 verdicts, one flag high on every one");
    $display("done: %0d errors", errors);
    $finish;
end
endmodule