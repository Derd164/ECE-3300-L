`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 03:46:14 PM
// Design Name: 
// Module Name: parity_tree8_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// parity_tree8_tb.v -- tree vs flat ^: two shapes, one truth
module parity_tree8_tb;
    reg [7:0] a;
    wire p_tree, p_flat;
    integer i, errors;
    parity_tree8 u_t (.a(a), .p(p_tree));
    parity_gen8 u_f (.d(a), .p(p_flat));
initial begin
    errors = 0;
    for (i = 0; i < 256; i = i + 1) begin
        a = i[7:0]; #10;
        if (p_tree !== p_flat) begin
            errors = errors + 1;
            $display("FAIL: shapes split at a=%h", a);
        end
        if (p_tree !== ^a) errors = errors + 1;
    end
    $display("tree == reduction ^ on all 256 words");
    $display("done: %0d errors", errors);
    $finish;
end
endmodule