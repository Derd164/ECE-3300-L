`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 03:31:01 PM
// Design Name: 
// Module Name: busmuxW_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// busmuxW_tb.v -- W=8: complements make every bit decisive
module busmuxW_tb;
    reg [7:0] a, b;
    reg sel;
    wire [7:0] y;
    integer i, errors;
    busmuxW #(.W(8)) dut (.a(a), .b(b), .sel(sel), .y(y));
initial begin
    errors = 0;
    // corners: a and b as exact complements
    a = 8'hAA; b = 8'h55; sel = 0; #10;
    $display("corner sel=0: y=%h (must be AA)", y);
    if (y !== 8'hAA) errors = errors + 1;
    sel = 1; #10;
    $display("corner sel=1: y=%h (must be 55)", y);
    if (y !== 8'h55) errors = errors + 1;
    // the sweep: a=i, b=~i -- any stuck slice betrays itself
    for (i = 0; i < 256; i = i + 1) begin
        a = i[7:0]; b = ~i[7:0];
        sel = 0; #10;
        if (y !== a) errors = errors + 1;
        sel = 1; #10;
        if (y !== b) errors = errors + 1;
    end
    $display("512 checks: every slice proved decisive");
    $display("done: %0d errors", errors);
    $finish;
end
endmodule