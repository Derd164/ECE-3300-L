`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 01:51:03 PM
// Design Name: 
// Module Name: half_adder_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// half_adder_tb.v -- four rows: count the 1s
module half_adder_tb;
    reg a, b;
    wire s, co;
    integer i, errors;
    half_adder dut (.a(a), .b(b), .s(s), .co(co));
initial begin
    errors = 0;
    for (i = 0; i < 4; i = i + 1) begin
        {b, a} = i[1:0];
        #10;
        $display("b=%b a=%b | co=%b s=%b", b, a, co, s);
        if ({co, s} !== a + b) errors = errors + 1;
    end
    $display("done: %0d errors", errors);
    $finish;
end
endmodule