`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 02:25:04 PM
// Design Name: 
// Module Name: parity_chk9_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// parity_chk9_tb.v -- good word, bit-flip attack, full sweep
module parity_chk9_tb;
    reg [7:0] d;
    reg p;
    wire err;
    integer i, k, g, errors;
    parity_chk9 dut (.d(d), .p(p), .err(err));
initial begin
    errors = 0;
    // corner: an honest word passes
    d = 8'hA5; p = 1'b0; #10; // A5 has four 1s -> p=0
    $display("corner A5 p=0: err=%b (clean)", err);
    if (err !== 1'b0) errors = errors + 1;
    // corner attack: flip ONE data bit -- err must rise
    d = 8'hA4; #10;
    $display("corner A4 p=0: err=%b (1 bit flipped)", err);
    if (err !== 1'b1) errors = errors + 1;
    // corner attack: flip the parity bit itself
    d = 8'hA5; p = 1'b1; #10;
    $display("corner A5 p=1: err=%b (parity flipped)", err);
    if (err !== 1'b1) errors = errors + 1;
    // the sweep: all 512 {p, d}
    for (i = 0; i < 512; i = i + 1) begin
        {p, d} = i[8:0]; #10;
        g = 0;
        for (k = i & 255; k > 0; k = k >> 1)
        g = g ^ (k & 1);
        if (err !== (g[0] ^ p)) errors = errors + 1;
    end
    $display("swept all 512 combinations");
    $display("done: %0d errors", errors);
    $finish;
end
endmodule