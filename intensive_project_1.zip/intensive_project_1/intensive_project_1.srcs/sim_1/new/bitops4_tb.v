`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/19/2026 03:23:27 PM
// Design Name: 
// Module Name: bitops4_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// bitops4_tb.v -- named corners first, then all 256 pairs
module bitops4_tb;
    reg [3:0] a, b;
    wire [3:0] y_and, y_or, y_xor, y_xnor;
    integer i, j, errors;
    bitops4 dut (.a(a), .b(b), .y_and(y_and), .y_or(y_or),
    .y_xor(y_xor), .y_xnor(y_xnor));
    task check;
begin
    if (y_and !== (a & b)) errors = errors + 1;
    if (y_or !== (a | b)) errors = errors + 1;
    if (y_xor !== (a ^ b)) errors = errors + 1;
    if (y_xnor !== ~(a ^ b)) errors = errors + 1;
    end
    endtask
initial begin
    errors = 0;
    // corners: extremes and the alternating patterns
    a = 4'b0000; b = 4'b0000; #10; check;
    $display("corner 0000,0000: and=%b or=%b", y_and, y_or);
    a = 4'b1111; b = 4'b1111; #10; check;
    $display("corner 1111,1111: xor=%b xnor=%b", y_xor, y_xnor);
    a = 4'b1010; b = 4'b0101; #10; check;
    $display("corner 1010,0101: and=%b or=%b xor=%b",
    y_and, y_or, y_xor);
    // the sweep: every pair, graded in silence
    for (i = 0; i < 16; i = i + 1)
    for (j = 0; j < 16; j = j + 1) begin
        a = i[3:0]; b = j[3:0];
        #10; check;
    end
    $display("swept all 256 pairs, 4 ops each");
    $display("done: %0d errors", errors);
    $finish;
end
endmodule
