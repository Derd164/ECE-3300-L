`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 12:12:06 PM
// Design Name: 
// Module Name: busmux2_4_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// busmux2_4_tb.v -- corners incl. the aliasing trap, then 512
module busmux2_4_tb;
    reg [3:0] a, b;
    reg sel;
    wire [3:0] y;
    integer i, errors;
    busmux2_4 dut (.a(a), .b(b), .sel(sel), .y(y));
initial begin
    errors = 0;
    // corner: extreme, obviously different inputs
    a = 4'h0; b = 4'hF; sel = 0; #10;
    $display("a=0 b=F sel=0 | y=%h", y);
    if (y !== 4'h0) errors = errors + 1;
    sel = 1; #10;
    $display("a=0 b=F sel=1 | y=%h", y);
    if (y !== 4'hF) errors = errors + 1;
    // corner: aliasing -- a == b hides a broken sel forever
    a = 4'h9; b = 4'h9; sel = 0; #10;
    if (y !== 4'h9) errors = errors + 1;
    sel = 1; #10;
    if (y !== 4'h9) errors = errors + 1;
    $display("aliasing corner a=b=9: both sels give 9");
    // the sweep: all 512 combos of {sel, b, a}
    for (i = 0; i < 512; i = i + 1) begin
        {sel, b, a} = i[8:0];
        #10;
        if (y !== (sel ? b : a)) errors = errors + 1;
    end
    $display("swept all 512 combinations");
    $display("done: %0d errors", errors);
    $finish;
end
endmodule
