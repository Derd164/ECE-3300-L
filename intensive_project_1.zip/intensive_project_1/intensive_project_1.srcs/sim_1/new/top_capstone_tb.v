`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 04:05:25 PM
// Design Name: 
// Module Name: top_capstone_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// top_capstone_tb.v -- three settings to verify on the board
module top_capstone_tb;
    reg [7:0] SW;
    wire [15:0] LED;
    wire [6:0] SEG;
    wire DP;
    wire [7:0] AN;
    integer errors;
    top_capstone dut (.SW(SW), .LED(LED), .SEG(SEG),
    .DP(DP), .AN(AN));
initial begin
    errors = 0;
    if (AN !== 8'b1111_1110) errors = errors + 1;
    if (DP !== 1'b1) errors = errors + 1;
    // all down: sum 0, digit 0, equal
    SW = 8'h00; #10;
    $display("SW=00: SEG=%b LED[15:13]=%b", SEG, LED[15:13]);
    if (SEG !== 7'b1000000) errors = errors + 1;
    if (LED[15:13] !== 3'b010) errors = errors + 1;
    // a=6 b=7: sum 13 -> digit d, lt verdict
    SW = 8'h76; #10;
    $display("SW=76: SEG=%b sum=%h (digit d)",
    SEG, LED[3:0]);
    if (SEG !== 7'b0100001) errors = errors + 1;
    if (LED[4:0] !== 5'b01101) errors = errors + 1;
    if (LED[15:13] !== 3'b001) errors = errors + 1;
    // a=F b=F: sum 30, carry up, digit E, equal
    SW = 8'hFF; #10;
    $display("SW=FF: SEG=%b cout=%b (digit E)",
    SEG, LED[4]);
    if (SEG !== 7'b0000110) errors = errors + 1;
    if (LED[4:0] !== 5'b11110) errors = errors + 1;
    if (LED[15:13] !== 3'b010) errors = errors + 1;
    $display("done: %0d errors", errors);
    $finish;
end
endmodule