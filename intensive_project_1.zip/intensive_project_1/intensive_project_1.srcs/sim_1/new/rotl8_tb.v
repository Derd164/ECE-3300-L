`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 02:43:59 PM
// Design Name: 
// Module Name: rotl8_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// rotl8_tb.v -- wraparound corners, then all 1024
module rotl8_tb;
    reg [7:0] a;
    reg [1:0] s;
    wire [7:0] y;
    integer i, av, sv, exp, errors;
    rotl8 dut (.a(a), .s(s), .y(y));
initial begin
    errors = 0;
    // corner: s=0 is the identity
    a = 8'hC3; s = 2'd0; #10;
    $display("corner C3 rot0: y=%h (identity)", y);
    if (y !== 8'hC3) errors = errors + 1;
    // corner: the MSB wraps to the bottom seat
    a = 8'h80; s = 2'd1; #10;
    $display("corner 80 rot1: y=%h (MSB came home)", y);
    if (y !== 8'h01) errors = errors + 1;
    // corner: rotate vs shift -- the difference on display
    a = 8'hE0; s = 2'd3; #10;
    $display("corner E0 rot3: y=%h (a shift says 00)", y);
    if (y !== 8'h07) errors = errors + 1;
    // the sweep: golden rotate from two masked shifts
    for (i = 0; i < 1024; i = i + 1) begin
        {s, a} = i[9:0]; #10;
        av = i & 255; sv = i >> 8;
        exp = ((av << sv) | (av >> (8 - sv))) & 255;
        if (sv == 0) exp = av;
        if (y !== exp[7:0]) errors = errors + 1;
    end
    $display("swept all 1024 combinations");
    $display("done: %0d errors", errors);
    $finish;
end
endmodule