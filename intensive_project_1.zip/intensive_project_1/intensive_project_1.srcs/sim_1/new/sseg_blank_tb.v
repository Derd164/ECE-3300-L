`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/20/2026 03:16:36 PM
// Design Name: 
// Module Name: sseg_blank_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// sseg_blank_tb.v -- pass-through vs curtain, all 32 combos
module sseg_blank_tb;
    reg [3:0] hex;
    reg blank;
    wire [6:0] seg, ref_seg;
    integer i, errors;
    sseg_blank dut (.hex(hex), .blank(blank), .seg(seg));
    sseg_hex u_ref (.hex(hex), .seg(ref_seg));
initial begin
    errors = 0;
    // blank=0: must match sseg_hex glyph for glyph
    blank = 0;
    for (i = 0; i < 16; i = i + 1) begin
        hex = i[3:0]; #10;
        if (seg !== ref_seg) begin
            errors = errors + 1;
            $display("FAIL pass-through at hex=%h", hex);
        end
    end
    $display("blank=0: all 16 glyphs pass through");
    // blank=1: the curtain -- every glyph goes dark
    blank = 1;
    for (i = 0; i < 16; i = i + 1) begin
        hex = i[3:0]; #10;
        if (seg !== 7'b1111111) begin
            errors = errors + 1;
            $display("FAIL curtain at hex=%h", hex);
        end
    end
    $display("blank=1: dark for all 16 inputs");
    $display("done: %0d errors", errors);
    $finish;
end
endmodule