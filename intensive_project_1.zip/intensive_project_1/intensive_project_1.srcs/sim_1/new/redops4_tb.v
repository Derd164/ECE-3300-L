`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/19/2026 03:27:56 PM
// Design Name: 
// Module Name: redops4_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// redops4_tb.v -- corners: extremes + one-hot walk, then sweep
module redops4_tb;
    reg [3:0] a;
    wire all_ones, any_one, parity;
    integer i, k, p, errors;
    redops4 dut (.a(a), .all_ones(all_ones),
    .any_one(any_one), .parity(parity));
initial begin
    errors = 0;
    // corners: both extremes
    a = 4'b0000; #10;
    $display("corner 0000: all=%b any=%b par=%b",
    all_ones, any_one, parity);
    if ({all_ones, any_one, parity} !== 3'b000)
    errors = errors + 1;
    a = 4'b1111; #10;
    $display("corner 1111: all=%b any=%b par=%b",
    all_ones, any_one, parity);
    if ({all_ones, any_one, parity} !== 3'b110)
    errors = errors + 1;
    // corners: the one-hot walk -- a lone 1 in each seat
    for (i = 0; i < 4; i = i + 1) begin
        a = 4'b0001 << i; #10;
        if ({all_ones, any_one, parity} !== 3'b011)
        errors = errors + 1;
    end
    $display("one-hot walk: any=1 parity=1 at every stop");
    // the sweep: all 16, golden parity counted bit by bit
    for (i = 0; i < 16; i = i + 1) begin
        a = i[3:0]; #10;
        p = 0;
        for (k = i; k > 0; k = k >> 1) p = p ^ (k & 1);
        if (all_ones !== (i == 15)) errors = errors + 1;
        if (any_one !== (i != 0)) errors = errors + 1;
        if (parity !== p[0]) errors = errors + 1;
    end
    $display("swept all 16 values, 3 ops each");
    $display("done: %0d errors", errors);
    $finish;
end
endmodule
